import { Link, NavLink } from 'react-router-dom'
import { useAppSelector } from '../app/hooks'
import { selectCartItemCount } from '../features/cart/cartSlice'

export default function Header() {
  const itemCount = useAppSelector(selectCartItemCount)

  return (
    <header className="header">
      <div className="container header-inner">
        <Link to="/" className="logo">
          <span className="logo-mark">🛒</span>
          <span>
            <strong>Ghaziabad Fresh Mart</strong>
            <small>your neighbourhood store, online</small>
          </span>
        </Link>

        <nav className="nav">
          <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>Home</NavLink>
          <NavLink to="/shop" className={({ isActive }) => (isActive ? 'active' : '')}>Shop</NavLink>
          <NavLink to="/orders" className={({ isActive }) => (isActive ? 'active' : '')}>My Orders</NavLink>
          <NavLink to="/support" className={({ isActive }) => (isActive ? 'active' : '')}>Support</NavLink>
        </nav>

        <Link to="/cart" className="cart-btn" aria-label="View cart">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
          </svg>
          <span>Cart</span>
          {itemCount > 0 && <span className="cart-badge">{itemCount}</span>}
        </Link>
      </div>
    </header>
  )
}
