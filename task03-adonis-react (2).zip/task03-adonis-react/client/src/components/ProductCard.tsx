import { useNavigate } from 'react-router-dom'
import type { MouseEvent } from 'react'
import { inr } from '../api'
import { useAppDispatch } from '../app/hooks'
import { addToCart } from '../features/cart/cartSlice'
import Media from './Media'
import Stars from './Stars'
import type { Product } from '../types'

export function offPct(p: Pick<Product, 'mrp' | 'price'>): number {
  return p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0
}

export default function ProductCard({ product: p }: { product: Product }) {
  const navigate = useNavigate()
  const dispatch = useAppDispatch()
  const off = offPct(p)

  const handleAdd = (e: MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation()
    void dispatch(addToCart({ productId: p.id, qty: 1 }))
  }

  return (
    <article className="card" onClick={() => navigate(`/product/${p.id}`)}>
      <div className="media">
        {off > 0 && <span className="badge-off">{off}% OFF</span>}
        <Media item={p} />
        {p.stock <= 0 ? (
          <span className="badge-out">Out of Stock</span>
        ) : (
          p.stock <= 5 && <span className="badge-low">Only {p.stock} left</span>
        )}
      </div>
      <div className="body">
        <span className="cat">{p.category}</span>
        <h3>{p.name}</h3>
        <span className="unit">{p.unit}</span>
        <span className="rating-row">
          <Stars rating={p.rating} /> <span>{p.rating} ({p.numReviews})</span>
        </span>
        <div className="price-row">
          <span className="price">{inr.format(p.price)}</span>
          {off > 0 && <span className="mrp">{inr.format(p.mrp)}</span>}
        </div>
        <div className="add-row">
          <button className="btn-add" disabled={p.stock <= 0} onClick={handleAdd}>
            {p.stock <= 0 ? 'Out of Stock' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </article>
  )
}
