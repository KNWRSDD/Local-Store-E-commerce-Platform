import { useState } from 'react'
import type { MediaItem } from '../types'

interface MediaProps {
  item: MediaItem
  eager?: boolean
}

/**
 * Product image with emoji-tile fallback if the image is missing/broken.
 */
export default function Media({ item, eager = false }: MediaProps) {
  const [failedSrc, setFailedSrc] = useState<string | null>(null)
  const showImg = item.image && failedSrc !== item.image

  return (
    <>
      <span className="emo">{item.emoji || '🛍️'}</span>
      {showImg && (
        <img
          src={item.image as string}
          alt={item.name}
          loading={eager ? 'eager' : 'lazy'}
          onError={() => setFailedSrc(item.image)}
        />
      )}
    </>
  )
}
