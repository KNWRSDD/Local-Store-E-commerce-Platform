import { useAppSelector } from '../app/hooks'
import { selectToasts } from '../features/toast/toastSlice'

/** Renders the fixed bottom toast stack, driven by the Redux toast slice */
export default function Toasts() {
  const toasts = useAppSelector(selectToasts)

  return (
    <div className="toasts" aria-live="assertive">
      {toasts.map((t) => (
        <div key={t.id} className={'toast' + (t.type ? ' ' + t.type : '')}>
          {t.message}
        </div>
      ))}
    </div>
  )
}
