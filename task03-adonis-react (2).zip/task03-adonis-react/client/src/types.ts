/** Shared types for the Fresh Mart API surface */

export interface Product {
  id: string
  name: string
  category: string
  price: number
  mrp: number
  unit: string
  emoji: string
  image: string | null
  desc: string
  details: string[]
  tags: string[]
  stock: number
  sold: number
  featured: boolean
  rating: number
  numReviews: number
}

export interface Review {
  id: number
  name: string
  rating: number
  comment: string
  date: string
}

export interface ProductDetailData extends Product {
  reviews: Review[]
}

export interface PriceBounds {
  min: number
  max: number
}

export interface ProductsListResponse {
  count: number
  categories: string[]
  priceBounds: PriceBounds
  products: Product[]
}

export interface ProductShowResponse {
  product: ProductDetailData
  related: Product[]
}

export interface CartItem {
  productId: string
  name: string
  unit: string
  emoji: string
  image: string | null
  price: number
  mrp: number
  qty: number
  stock: number
  lineTotal: number
}

export interface CartView {
  items: CartItem[]
  itemCount: number
  subtotal: number
  deliveryFee: number
  total: number
  freeDeliveryAbove: number
  amountToFreeDelivery: number
}

export type StatusKey = 'placed' | 'confirmed' | 'packed' | 'out' | 'delivered'

export interface OrderItem {
  name: string
  unit: string
  emoji: string
  image: string | null
  price: number
  qty: number
  lineTotal: number
}

export interface OrderCustomer {
  name: string
  phone: string
  address: string
  landmark: string | null
  notes: string | null
}

export interface TimelineStep {
  key: StatusKey
  label: string
  desc: string
  done: boolean
  current: boolean
  time: number
}

export interface Order {
  id: string
  customer: OrderCustomer
  items: OrderItem[]
  subtotal: number
  deliveryFee: number
  total: number
  payment: 'cod' | 'upi'
  paymentLabel: string
  createdAt: number
  status: string
  statusKey: StatusKey
  timeline: TimelineStep[]
}

export interface Ticket {
  id: string
  name?: string
  email?: string
  subject: string
  message: string
  status: string
  reply: string | null
  createdAt: number
}

/** Minimal shape needed by the <Media> fallback component */
export interface MediaItem {
  image: string | null
  name: string
  emoji?: string
}
