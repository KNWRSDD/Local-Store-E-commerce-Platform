import { configureStore } from '@reduxjs/toolkit'
import cartReducer from '../features/cart/cartSlice'
import toastReducer from '../features/toast/toastSlice'

/**
 * The single global store: cart state + toast notifications.
 * Any component can read it with useAppSelector and update it by
 * dispatching actions/thunks with useAppDispatch.
 */
export const store = configureStore({
  reducer: {
    cart: cartReducer,
    toast: toastReducer,
  },
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
