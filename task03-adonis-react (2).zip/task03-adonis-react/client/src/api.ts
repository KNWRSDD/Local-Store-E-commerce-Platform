/**
 * Public API surface for pages/components:
 * the axios HTTP layer (src/lib/http) + shared formatters.
 */
export { api, ApiError, http, httpGet, httpPost, httpPut, httpDelete } from './lib/http'
export type { ApiErrorData, ApiOptions } from './lib/http'

import type { StatusKey } from './types'

export const inr: Intl.NumberFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

export function orderDate(ts: number): string {
  return new Date(ts).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  })
}

export const CAT_EMOJI: Record<string, string> = {
  'Staples & Grocery': '🌾',
  'Dairy & Fresh': '🥛',
  'Snacks & Beverages': '🍪',
  'Personal Care': '🧴',
  'Household Essentials': '🧺',
}

export const STATUS_STEPS_ICONS: Record<StatusKey, string> = {
  placed: '🧾',
  confirmed: '✅',
  packed: '📦',
  out: '🛵',
  delivered: '🏠',
}

export function statusClass(key: StatusKey): string {
  return 'status-' + key
}
