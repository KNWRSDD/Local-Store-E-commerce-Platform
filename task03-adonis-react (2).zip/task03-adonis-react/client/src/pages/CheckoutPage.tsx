import { useState } from 'react'
import type { ChangeEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, inr } from '../api'
import { useAppDispatch, useAppSelector } from '../app/hooks'
import { clearLocalCart, selectCart, selectCartLoaded } from '../features/cart/cartSlice'
import { showToast } from '../features/toast/toastSlice'
import type { Order } from '../types'

type PaymentMethod = 'cod' | 'upi'

interface CheckoutForm {
  name: string
  phone: string
  address: string
  landmark: string
  notes: string
  payment: PaymentMethod
}

type FormErrors = Partial<Record<'name' | 'phone' | 'address' | 'payment', boolean>>

const EMPTY: CheckoutForm = { name: '', phone: '', address: '', landmark: '', notes: '', payment: 'cod' }

const PAYMENT_OPTIONS: { value: PaymentMethod; title: string; sub: string }[] = [
  { value: 'cod', title: '💵 Cash on Delivery', sub: 'Pay in cash when your order arrives' },
  { value: 'upi', title: '📱 UPI on Delivery', sub: 'Scan our QR code at the door — GPay / PhonePe / Paytm' },
]

export default function CheckoutPage() {
  const cart = useAppSelector(selectCart)
  const loaded = useAppSelector(selectCartLoaded)
  const dispatch = useAppDispatch()
  const navigate = useNavigate()
  const [form, setForm] = useState<CheckoutForm>(EMPTY)
  const [errors, setErrors] = useState<FormErrors>({})
  const [placing, setPlacing] = useState(false)

  if (loaded && cart.items.length === 0 && !placing) {
    return (
      <div className="empty-state">
        <div className="big">🧺</div>
        <h3>Nothing to check out</h3>
        <p>Your cart is empty — add products first.</p>
        <button className="btn btn-primary" onClick={() => navigate('/shop')}>Go to shop</button>
      </div>
    )
  }

  const set =
    (key: keyof CheckoutForm) =>
    (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value }))

  const validate = (): boolean => {
    const next: FormErrors = {}
    if (form.name.trim().length < 2) next.name = true
    if (!/^[6-9]\d{9}$/.test(form.phone.replace(/\s/g, ''))) next.phone = true
    if (form.address.trim().length < 10) next.address = true
    if (!form.payment) next.payment = true
    setErrors(next)
    return Object.keys(next).length === 0
  }

  const placeOrder = async () => {
    if (!validate()) {
      dispatch(showToast('Please fix the highlighted fields', 'error'))
      return
    }
    setPlacing(true)
    try {
      const { order } = await api<{ order: Order }>('/api/orders', {
        method: 'POST',
        body: { ...form, phone: form.phone.replace(/\s/g, '') },
      })
      dispatch(clearLocalCart())
      dispatch(showToast('Order placed successfully! 🎉', 'success'))
      navigate(`/orders/${order.id}?placed=1`)
    } catch (err) {
      dispatch(showToast(err instanceof Error ? err.message : 'Could not place order', 'error'))
      setPlacing(false)
    }
  }

  return (
    <>
      <h2 className="section-title">Checkout</h2>
      <p className="section-sub">Confirm your delivery details and place the order</p>

      <div className="cart-layout">
        <form className="card-panel" noValidate onSubmit={(e) => e.preventDefault()}>
          <div className={'field' + (errors.name ? ' invalid' : '')}>
            <label htmlFor="coName">Full name *</label>
            <input id="coName" type="text" autoComplete="name" placeholder="e.g. Rahul Verma" value={form.name} onChange={set('name')} />
            <p className="field-err">Please enter your full name.</p>
          </div>
          <div className={'field' + (errors.phone ? ' invalid' : '')}>
            <label htmlFor="coPhone">Mobile number *</label>
            <input id="coPhone" type="tel" maxLength={10} inputMode="numeric" autoComplete="tel" placeholder="10-digit mobile number" value={form.phone} onChange={set('phone')} />
            <p className="field-err">Enter a valid 10-digit Indian mobile number.</p>
          </div>
          <div className={'field' + (errors.address ? ' invalid' : '')}>
            <label htmlFor="coAddr">Delivery address *</label>
            <textarea id="coAddr" autoComplete="street-address" placeholder="House no., street, area, Ghaziabad…" value={form.address} onChange={set('address')} />
            <p className="field-err">Please enter a complete address (min 10 characters).</p>
          </div>
          <div className="field">
            <label htmlFor="coLandmark">Landmark (optional)</label>
            <input id="coLandmark" type="text" placeholder="Near…" value={form.landmark} onChange={set('landmark')} />
          </div>
          <div className="field">
            <label htmlFor="coNotes">Delivery notes (optional)</label>
            <input id="coNotes" type="text" placeholder="e.g. Ring the bell twice, leave at door" value={form.notes} onChange={set('notes')} />
          </div>

          <div className={'field' + (errors.payment ? ' invalid' : '')}>
            <label>Payment method *</label>
            {PAYMENT_OPTIONS.map((opt) => (
              <label
                key={opt.value}
                className={'pay-opt' + (form.payment === opt.value ? ' sel' : '')}
                onClick={() => setForm((f) => ({ ...f, payment: opt.value }))}
              >
                <input type="radio" name="pay" value={opt.value} checked={form.payment === opt.value} readOnly />
                <div><h5>{opt.title}</h5><p>{opt.sub}</p></div>
              </label>
            ))}
            <p className="field-err">Please choose a payment method.</p>
          </div>
        </form>

        <aside className="summary-card">
          <h3>Order summary</h3>
          {cart.items.map((i) => (
            <div className="summary-row" key={i.productId}>
              <span>{i.emoji} {i.name} × {i.qty}</span>
              <span>{inr.format(i.lineTotal)}</span>
            </div>
          ))}
          <div className="summary-row">
            <span>Delivery</span>
            <span>{cart.deliveryFee === 0 ? 'FREE' : inr.format(cart.deliveryFee)}</span>
          </div>
          <div className="summary-row total"><span>Total</span><span>{inr.format(cart.total)}</span></div>
          <button
            className="btn btn-primary block"
            style={{ marginTop: 16 }}
            disabled={placing}
            onClick={() => void placeOrder()}
          >
            {placing ? 'Placing order…' : `Place Order · ${inr.format(cart.total)}`}
          </button>
          <p className="free-ship-note" style={{ marginTop: 10, textAlign: 'center' }}>
            🚚 Expected delivery: within 60–90 minutes
          </p>
        </aside>
      </div>
    </>
  )
}
