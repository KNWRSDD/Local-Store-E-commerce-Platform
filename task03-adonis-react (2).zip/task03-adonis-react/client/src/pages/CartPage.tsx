import { Link, useNavigate } from 'react-router-dom'
import { inr } from '../api'
import { useAppDispatch, useAppSelector } from '../app/hooks'
import { selectCart, selectCartLoaded, setCartQty } from '../features/cart/cartSlice'
import Media from '../components/Media'

export default function CartPage() {
  const cart = useAppSelector(selectCart)
  const loaded = useAppSelector(selectCartLoaded)
  const dispatch = useAppDispatch()
  const navigate = useNavigate()

  if (loaded && cart.items.length === 0) {
    return (
      <div className="empty-state">
        <div className="big">🛒</div>
        <h3>Your cart is empty</h3>
        <p>Add some fresh essentials and come back here.</p>
        <Link className="btn btn-primary" to="/shop">Start shopping</Link>
      </div>
    )
  }

  const pct = Math.min(100, (cart.subtotal / cart.freeDeliveryAbove) * 100)
  const savings = cart.items.reduce((sum, i) => sum + (i.mrp - i.price) * i.qty, 0)

  return (
    <>
      <h2 className="section-title">Your cart</h2>
      <p className="section-sub">
        {cart.itemCount} item{cart.itemCount === 1 ? '' : 's'} in your basket
      </p>

      <div className="cart-layout">
        <div>
          {cart.items.map((i) => (
            <div className="cart-item" key={i.productId}>
              <div className="cart-thumb"><Media item={i} /></div>
              <div>
                <h4>{i.name}</h4>
                <span className="unit-price">{inr.format(i.price)} · {i.unit}</span>
                <div style={{ marginTop: 8 }}>
                  <div className="qty-box small">
                    <button onClick={() => void dispatch(setCartQty({ productId: i.productId, qty: i.qty - 1 }))}>−</button>
                    <span>{i.qty}</span>
                    <button
                      onClick={() => void dispatch(setCartQty({ productId: i.productId, qty: i.qty + 1 }))}
                      disabled={i.qty >= i.stock}
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
              <div className="right">
                <span className="line-total">{inr.format(i.lineTotal)}</span>
                <button className="remove-btn" onClick={() => void dispatch(setCartQty({ productId: i.productId, qty: 0 }))}>
                  Remove
                </button>
              </div>
            </div>
          ))}
          <Link className="btn btn-outline" to="/shop">← Continue shopping</Link>
        </div>

        <aside className="summary-card">
          <h3>Bill summary</h3>
          <span className="savings-chip">You save {inr.format(savings)} on MRP 🎉</span>
          <div className="free-ship-bar"><div className="fill" style={{ width: pct + '%' }} /></div>
          <p className="free-ship-note">
            {cart.deliveryFee === 0
              ? '✅ You have unlocked free delivery!'
              : `Add ${inr.format(cart.amountToFreeDelivery)} more for free delivery`}
          </p>
          <div className="summary-row"><span>Subtotal</span><span>{inr.format(cart.subtotal)}</span></div>
          <div className="summary-row">
            <span>Delivery fee</span>
            <span>{cart.deliveryFee === 0 ? 'FREE' : inr.format(cart.deliveryFee)}</span>
          </div>
          <div className="summary-row total"><span>To pay</span><span>{inr.format(cart.total)}</span></div>
          <button
            className="btn btn-primary block"
            style={{ marginTop: 16 }}
            onClick={() => navigate('/checkout')}
          >
            Proceed to Checkout →
          </button>
        </aside>
      </div>
    </>
  )
}
