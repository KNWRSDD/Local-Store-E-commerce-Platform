import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { api, inr, orderDate, statusClass, STATUS_STEPS_ICONS } from '../api'
import type { Order } from '../types'

export default function TrackPage() {
  const { id } = useParams<{ id: string }>()
  const [searchParams] = useSearchParams()
  const justPlaced = searchParams.get('placed') === '1'
  const [order, setOrder] = useState<Order | null>(null)
  const [missing, setMissing] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    let cancelled = false
    let timer: ReturnType<typeof setTimeout>

    const load = async () => {
      try {
        const data = await api<{ order: Order }>('/api/orders/' + encodeURIComponent(id ?? ''))
        if (cancelled) return
        setOrder(data.order)
        if (data.order.statusKey !== 'delivered') timer = setTimeout(load, 8000)
      } catch {
        if (!cancelled) setMissing(true)
      }
    }
    setOrder(null)
    setMissing(false)
    void load()
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [id])

  if (missing) {
    return (
      <div className="empty-state">
        <div className="big">🔎</div>
        <h3>Order not found</h3>
        <p>Double-check the order ID, or view all your orders.</p>
        <button className="btn btn-primary" onClick={() => navigate('/orders')}>Back to my orders</button>
      </div>
    )
  }
  if (!order) return null

  return (
    <>
      {justPlaced && (
        <div className="success-banner">
          <span className="tick">✓</span>
          <div>
            <h3>Order placed successfully! 🎉</h3>
            <p className="muted">
              Thank you, {order.customer.name.split(' ')[0]}! Your order <strong>{order.id}</strong>{' '}
              is being prepared at the store.
            </p>
          </div>
        </div>
      )}

      <p className="breadcrumb"><Link to="/orders">My Orders</Link> / {order.id}</p>

      <div className="track-layout">
        <div className="card-panel">
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <h2 style={{ letterSpacing: '-.3px' }}>{order.id}</h2>
            <span className={'status-chip ' + statusClass(order.statusKey)}>{order.status}</span>
            <span className="muted" style={{ fontSize: '.8rem' }}>Placed {orderDate(order.createdAt)}</span>
          </div>

          <div className="timeline">
            {order.timeline.map((s) => (
              <div
                key={s.key}
                className={`tl-step ${s.done ? 'done' : 'pending'} ${s.current ? 'current' : ''}`}
              >
                <span className="tl-dot">{STATUS_STEPS_ICONS[s.key]}</span>
                <div className="tl-body">
                  <h4>
                    {s.label}
                    {s.done && <span className="time">{orderDate(s.time)}</span>}
                  </h4>
                  <p>{s.current && s.key !== 'delivered' ? s.desc + ' (live)' : s.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {order.statusKey === 'delivered' ? (
            <div className="info-block" style={{ background: 'var(--green-soft)' }}>
              🎉 <strong>Delivered!</strong> We hope you love everything.{' '}
              <Link to="/shop" style={{ color: 'var(--green)', fontWeight: 700 }}>Order again →</Link>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: '.8rem' }}>
              Page auto-refreshes while the order is on its way. Expected delivery: 60–90 minutes.
            </p>
          )}
        </div>

        <aside>
          <div className="summary-card" style={{ position: 'static' }}>
            <h3>Delivery details</h3>
            <div className="info-block">
              <h5>Deliver to</h5>
              <strong>{order.customer.name}</strong> · {order.customer.phone}
              <br />
              {order.customer.address}
              {order.customer.landmark && <><br />Landmark: {order.customer.landmark}</>}
              {order.customer.notes && (
                <><br /><span className="muted">Note: {order.customer.notes}</span></>
              )}
            </div>
            <div className="info-block">
              <h5>Payment</h5>
              {order.paymentLabel} · <strong>{inr.format(order.total)}</strong>
            </div>
          </div>

          <div className="summary-card" style={{ position: 'static', marginTop: 14 }}>
            <h3>Items ({order.items.reduce((sum, i) => sum + i.qty, 0)})</h3>
            {order.items.map((i, idx) => (
              <div className="summary-row" key={idx}>
                <span>{i.emoji} {i.name} × {i.qty}</span>
                <span>{inr.format(i.lineTotal)}</span>
              </div>
            ))}
            <div className="summary-row">
              <span>Delivery</span>
              <span>{order.deliveryFee === 0 ? 'FREE' : inr.format(order.deliveryFee)}</span>
            </div>
            <div className="summary-row total"><span>Total</span><span>{inr.format(order.total)}</span></div>
            <button
              className="btn btn-outline block"
              style={{ marginTop: 14 }}
              onClick={() => navigate('/support')}
            >
              Need help with this order?
            </button>
          </div>
        </aside>
      </div>
    </>
  )
}
