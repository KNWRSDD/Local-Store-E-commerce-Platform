import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { api, inr, orderDate, statusClass } from '../api'
import type { Order } from '../types'

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[] | null>(null)
  const navigate = useNavigate()

  useEffect(() => {
    let cancelled = false
    let timer: ReturnType<typeof setTimeout>

    const load = async () => {
      try {
        const data = await api<{ orders: Order[] }>('/api/orders')
        if (cancelled) return
        setOrders(data.orders)
        if (data.orders.some((o) => o.statusKey !== 'delivered')) {
          timer = setTimeout(load, 10000)
        }
      } catch {
        if (!cancelled) setOrders([])
      }
    }
    void load()
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [])

  if (orders === null) return null

  if (orders.length === 0) {
    return (
      <div className="empty-state">
        <div className="big">📦</div>
        <h3>No orders yet</h3>
        <p>Your placed orders will appear here with live tracking.</p>
        <Link className="btn btn-primary" to="/shop">Order something fresh</Link>
      </div>
    )
  }

  return (
    <>
      <h2 className="section-title">My orders</h2>
      <p className="section-sub">
        {orders.length} order{orders.length === 1 ? '' : 's'} · tap any order to track it live
      </p>

      {orders.map((o) => (
        <div className="order-card" key={o.id}>
          <div className="top">
            <span className="oid">{o.id}</span>
            <span className={'status-chip ' + statusClass(o.statusKey)}>{o.status}</span>
            <span className="muted" style={{ fontSize: '.8rem' }}>{orderDate(o.createdAt)}</span>
          </div>
          <div className="order-thumbs">
            {o.items.slice(0, 6).map((i, idx) => (
              <span className="order-chip" key={idx}>{i.emoji} {i.name} × {i.qty}</span>
            ))}
            {o.items.length > 6 && <span className="order-chip">+{o.items.length - 6} more</span>}
          </div>
          <div className="bottom">
            <div>
              <strong>{inr.format(o.total)}</strong>{' '}
              <span className="muted" style={{ fontSize: '.82rem' }}>· {o.paymentLabel}</span>
            </div>
            <button className="btn btn-outline" onClick={() => navigate(`/orders/${o.id}`)}>
              Track order →
            </button>
          </div>
        </div>
      ))}

      <p className="muted" style={{ marginTop: 14, fontSize: '.8rem' }}>
        ℹ️ Demo note: statuses advance automatically on a short timer so you can watch the full
        journey live.
      </p>
    </>
  )
}
