import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api, CAT_EMOJI } from '../api'
import ProductCard from '../components/ProductCard'
import Stars from '../components/Stars'
import type { ProductsListResponse } from '../types'

interface ShopFilters {
  q: string
  categories: Set<string>
  min: string
  max: string
  rating: number
  inStock: boolean
  sort: string
}

interface ShopMeta {
  categories: string[]
  priceBounds: { min: number; max: number }
}

const EMPTY_FILTERS: ShopFilters = {
  q: '',
  categories: new Set<string>(),
  min: '',
  max: '',
  rating: 0,
  inStock: false,
  sort: 'featured',
}

export default function Shop() {
  const [searchParams] = useSearchParams()
  const [meta, setMeta] = useState<ShopMeta>({ categories: [], priceBounds: { min: 0, max: 0 } })
  const [filters, setFilters] = useState<ShopFilters>(() => ({
    ...EMPTY_FILTERS,
    q: searchParams.get('q') || '',
    categories: new Set<string>((searchParams.get('category') || '').split(',').filter(Boolean)),
  }))
  const [result, setResult] = useState<Pick<ProductsListResponse, 'products' | 'count'>>({
    products: [],
    count: 0,
  })
  const [panelOpen, setPanelOpen] = useState(false)

  useEffect(() => {
    api<ProductsListResponse>('/api/products')
      .then((d) => setMeta(d))
      .catch(() => {})
  }, [])

  const queryString = useMemo(() => {
    const params = new URLSearchParams()
    if (filters.q) params.set('q', filters.q)
    if (filters.categories.size) params.set('category', [...filters.categories].join(','))
    if (filters.min) params.set('minPrice', filters.min)
    if (filters.max) params.set('maxPrice', filters.max)
    if (filters.rating) params.set('minRating', String(filters.rating))
    if (filters.inStock) params.set('inStock', '1')
    if (filters.sort !== 'featured') params.set('sort', filters.sort)
    return params.toString()
  }, [filters])

  useEffect(() => {
    let cancelled = false
    const timer: ReturnType<typeof setTimeout> = setTimeout(async () => {
      try {
        const data = await api<ProductsListResponse>('/api/products?' + queryString)
        if (!cancelled) setResult(data)
      } catch {
        /* keep previous results */
      }
    }, 250)
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [queryString])

  const patch = (changes: Partial<ShopFilters>) => setFilters((f) => ({ ...f, ...changes }))
  const clearFilters = () => setFilters(EMPTY_FILTERS)

  const toggleCategory = (c: string, checked: boolean) => {
    const next = new Set<string>(filters.categories)
    if (checked) next.add(c)
    else next.delete(c)
    patch({ categories: next })
  }

  return (
    <>
      <h2 className="section-title">Shop all products</h2>
      <p className="section-sub">Search, filter and sort the full store catalogue</p>
      <div className="shop-layout">
        <aside className={'filters' + (panelOpen ? ' open' : '')}>
          <h4>Categories</h4>
          {meta.categories.map((c) => (
            <label key={c}>
              <input
                type="checkbox"
                checked={filters.categories.has(c)}
                onChange={(e) => toggleCategory(c, e.target.checked)}
              />
              {' ' + (CAT_EMOJI[c] || '')} {c}
            </label>
          ))}

          <h4>Price (₹)</h4>
          <div className="price-inputs">
            <input
              type="number"
              min="0"
              placeholder={String(meta.priceBounds.min)}
              value={filters.min}
              onChange={(e) => patch({ min: e.target.value })}
            />
            <span className="muted">–</span>
            <input
              type="number"
              min="0"
              placeholder={String(meta.priceBounds.max)}
              value={filters.max}
              onChange={(e) => patch({ max: e.target.value })}
            />
          </div>

          <h4>Minimum rating</h4>
          {[4.5, 4, 0].map((r) => (
            <label key={r}>
              <input
                type="radio"
                name="rating"
                checked={filters.rating === r}
                onChange={() => patch({ rating: r })}
              />{' '}
              {r === 0 ? 'Any rating' : <><Stars rating={r} /> {r} &amp; above</>}
            </label>
          ))}

          <h4>Availability</h4>
          <label>
            <input
              type="checkbox"
              checked={filters.inStock}
              onChange={(e) => patch({ inStock: e.target.checked })}
            />{' '}
            In stock only
          </label>

          <button className="clear-btn" onClick={clearFilters}>✕ Clear all filters</button>
        </aside>

        <section>
          <div className="shop-toolbar">
            <button className="btn btn-outline filter-toggle" onClick={() => setPanelOpen((o) => !o)}>
              ☰ Filters
            </button>
            <div className="search-wrap">
              <span>🔍</span>
              <input
                type="text"
                placeholder="Search products…"
                value={filters.q}
                onChange={(e) => patch({ q: e.target.value })}
              />
            </div>
            <select
              className="sort-select"
              value={filters.sort}
              onChange={(e) => patch({ sort: e.target.value })}
              aria-label="Sort products"
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-asc">Price: Low → High</option>
              <option value="price-desc">Price: High → Low</option>
              <option value="rating">Top Rated</option>
              <option value="savings">Biggest Savings</option>
              <option value="name">Name: A → Z</option>
            </select>
          </div>

          <p className="result-count">
            {result.count} product{result.count === 1 ? '' : 's'} found
          </p>

          <div className="prod-grid">
            {result.count > 0 ? (
              result.products.map((p) => <ProductCard key={p.id} product={p} />)
            ) : (
              <div className="empty-state" style={{ gridColumn: '1/-1' }}>
                <div className="big">🔍</div>
                <h3>No products match</h3>
                <p>Try removing some filters or searching something else.</p>
                <button className="btn btn-outline" onClick={clearFilters}>Clear filters</button>
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  )
}
