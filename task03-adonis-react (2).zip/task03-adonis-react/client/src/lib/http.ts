/**
 * Axios-based HTTP layer for the Fresh Mart API.
 * - pre-configured axios instance (base URL, JSON headers, session cookie)
 * - response interceptor that normalises backend errors (incl. VineJS 422s)
 */
import axios, { AxiosError } from 'axios'
import type { AxiosRequestConfig } from 'axios'
import type { CartView } from '../types'

/** Shapes of error bodies the AdonisJS backend can return */
export interface ApiErrorData {
  error?: string
  message?: string
  errors?: { message: string; field?: string; rule?: string }[]
  cart?: CartView
}

export class ApiError extends Error {
  data: ApiErrorData | null
  status: number

  constructor(message: string, status: number, data: ApiErrorData | null = null) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.data = data
  }
}

/** Pre-configured axios instance: same-origin API, JSON body, session cookie, 15s timeout */
export const http = axios.create({
  baseURL: '/',
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
})

/** Convert every HTTP failure into a friendly ApiError */
http.interceptors.response.use(
  (response) => response,
  (error: AxiosError<ApiErrorData>) => {
    const data = error.response?.data ?? null
    const message =
      data?.errors?.[0]?.message ||
      data?.error ||
      data?.message ||
      error.message ||
      'Something went wrong'
    return Promise.reject(new ApiError(message, error.response?.status ?? 0, data))
  }
)

/* Typed verb helpers — used by the Redux thunks */
export const httpGet = <T>(path: string) => http.get<T>(path).then((r) => r.data)
export const httpPost = <T, B = unknown>(path: string, body?: B) =>
  http.post<T>(path, body).then((r) => r.data)
export const httpPut = <T, B = unknown>(path: string, body?: B) =>
  http.put<T>(path, body).then((r) => r.data)
export const httpDelete = <T>(path: string) => http.delete<T>(path).then((r) => r.data)

export interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'
  body?: unknown
  headers?: Record<string, string>
}

/** Fetch-style convenience wrapper kept for page-level one-off calls */
export async function api<T = unknown>(path: string, options: ApiOptions = {}): Promise<T> {
  const config: AxiosRequestConfig = {
    url: path,
    method: options.method ?? 'GET',
    data: options.body,
    headers: options.headers,
  }
  const res = await http.request<T>(config)
  return res.data
}
