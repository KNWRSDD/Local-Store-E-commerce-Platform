import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import { ApiError, httpDelete, httpGet, httpPost, httpPut } from '../../lib/http'
import type { RootState } from '../../app/store'
import { showToast } from '../toast/toastSlice'
import type { CartView } from '../../types'

interface CartState {
  view: CartView
  loaded: boolean
}

const EMPTY_CART: CartView = {
  items: [],
  itemCount: 0,
  subtotal: 0,
  deliveryFee: 0,
  total: 0,
  freeDeliveryAbove: 499,
  amountToFreeDelivery: 499,
}

const initialState: CartState = { view: EMPTY_CART, loaded: false }

/* ---------------- async thunks (server is the source of truth) ----------- */

/** Initial load: GET the session cart once when the app starts */
export const fetchCart = createAsyncThunk<CartView>('cart/fetchCart', () =>
  httpGet<CartView>('/api/cart')
)

/** Add a product to the cart; shows success/error toasts */
export const addToCart = createAsyncThunk<
  CartView,
  { productId: string; qty?: number },
  { rejectValue: string }
>('cart/addToCart', async ({ productId, qty = 1 }, { dispatch, rejectWithValue }) => {
  try {
    const cart = await httpPost<CartView>('/api/cart', { productId, qty })
    dispatch(showToast('Added to cart 🛒', 'success'))
    return cart
  } catch (err) {
    // stock overflow — backend returns 409 with the capped cart; sync it
    if (err instanceof ApiError && err.data?.cart) {
      dispatch(cartLoaded(err.data.cart))
    }
    const message = err instanceof Error ? err.message : 'Could not add to cart'
    dispatch(showToast(message, 'error'))
    return rejectWithValue(message)
  }
})

/** Set an exact quantity (qty <= 0 removes the line item) */
export const setCartQty = createAsyncThunk<
  CartView,
  { productId: string; qty: number },
  { rejectValue: string }
>('cart/setCartQty', async ({ productId, qty }, { rejectWithValue }) => {
  try {
    if (qty <= 0) {
      return await httpDelete<CartView>(`/api/cart/${productId}`)
    }
    return await httpPut<CartView>(`/api/cart/${productId}`, { qty })
  } catch (err) {
    return rejectWithValue(err instanceof Error ? err.message : 'Could not update cart')
  }
})

/* ---------------- slice -------------------------------------------------- */

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    /** Replace the whole cart view (used when syncing server responses) */
    cartLoaded: (state, action: PayloadAction<CartView>) => {
      state.view = action.payload
    },
    /** Reset locally after a successful checkout (server cleared it already) */
    clearLocalCart: (state) => {
      state.view = EMPTY_CART
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCart.fulfilled, (state, action) => {
        state.view = action.payload
        state.loaded = true
      })
      .addCase(fetchCart.rejected, (state) => {
        state.loaded = true // keep previous state but stop the "empty" guard flicker
      })
      .addCase(addToCart.fulfilled, (state, action) => {
        state.view = action.payload
        state.loaded = true
      })
      .addCase(setCartQty.fulfilled, (state, action) => {
        state.view = action.payload
      })
  },
})

export const { cartLoaded, clearLocalCart } = cartSlice.actions

/* ---------------- selectors ---------------------------------------------- */

export const selectCart = (state: RootState) => state.cart.view
export const selectCartLoaded = (state: RootState) => state.cart.loaded
export const selectCartItemCount = (state: RootState) => state.cart.view.itemCount

export default cartSlice.reducer
