import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction, UnknownAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

export type ToastType = '' | 'success' | 'error'

export interface ToastItem {
  id: number
  message: string
  type: ToastType
}

interface ToastState {
  items: ToastItem[]
}

let nextId = 1

const toastSlice = createSlice({
  name: 'toast',
  initialState: { items: [] } as ToastState,
  reducers: {
    addToast: (state, action: PayloadAction<ToastItem>) => {
      state.items.push(action.payload)
    },
    removeToast: (state, action: PayloadAction<number>) => {
      state.items = state.items.filter((t) => t.id !== action.payload)
    },
  },
})

export const { addToast, removeToast } = toastSlice.actions

/**
 * Thunk: show a toast and auto-dismiss it after 3 seconds.
 * Usage: dispatch(showToast('Added to cart', 'success'))
 */
export const showToast =
  (message: string, type: ToastType = '') =>
  (dispatch: (action: UnknownAction) => unknown) => {
    const id = nextId++
    dispatch(addToast({ id, message, type }))
    setTimeout(() => dispatch(removeToast(id)), 3000)
  }

export const selectToasts = (state: RootState) => state.toast.items

export default toastSlice.reducer
