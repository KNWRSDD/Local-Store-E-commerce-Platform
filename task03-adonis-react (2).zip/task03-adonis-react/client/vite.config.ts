import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:3333',
    },
  },
  build: {
    // AdonisJS (@adonisjs/static) serves this folder on port 3333
    outDir: '../server/public',
    emptyOutDir: true,
  },
})
