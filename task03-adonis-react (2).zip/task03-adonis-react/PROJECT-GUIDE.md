# 📘 Project Guide — Ghaziabad Fresh Mart (AdonisJS + React)

How everything fits together, in plain language: architecture diagrams,
request flows, what every backend function does, and what every frontend page does.

---

## 1. 🔭 The Big Picture (30,000-ft view)

```
┌──────────────────────────────────────────────────────────────────────────┐
│                              USER'S BROWSER                              │
│                                                                          │
│   React SPA (Vite build)  ──►  UI pages, cart badge, toasts              │
│   src/client files served as static JS/CSS                               │
│                                                                          │
│         │  fetch('/api/...')          (same origin, session cookie)      │
│         ▼                                                                │
└──────────────────────────────────────────────────────────────────────────┘
         │                        │
         │ GET / , /assets, /img  │ GET/POST/PUT/DELETE  /api/*
         ▼                        ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                     ADONISJS SERVER  (single port 3333)                  │
│                                                                          │
│  ┌─────────────────────┐   ┌──────────────────────────────────────────┐  │
│  │ @adonisjs/static    │   │              ROUTER (start/routes.ts)     │  │
│  │ serves React build  │   │  /api/products  /api/cart  /api/orders    │  │
│  │ from server/public/ │   │  /api/support                            │  │
│  └─────────────────────┘   └──────────────────┬───────────────────────┘  │
│                                                │                         │
│        MIDDLEWARE PIPELINE (start/kernel.ts)  │                          │
│  CORS → static → bodyparser → SESSION → shield → auth → controllers     │
│                                                │                         │
│  ┌─────────────────────────── CONTROLLERS ────────────────────────────┐  │
│  │ ProductsController   CartController   OrdersController   Support   │  │
│  └────────┬──────────────────────┬─────────────────┬─────────────────┘  │
│           │                      │                 │                    │
│  ┌────────▼────────┐   ┌────────▼─────────┐  ┌────▼───────────────┐    │
│  │ CartService      │   │ OrderTracking    │  │ VineJS Validators  │    │
│  │ (cart math)      │   │ (live timeline)  │  │ (input checking)   │    │
│  └──────────────────┘   └──────────────────┘  └────────────────────┘    │
│                                    │                                     │
│                          LUCID ORM MODELS                                │
│        Product · Review · CartItem · Order · OrderItem · Ticket          │
│                                    │                                     │
└────────────────────────────────────┼─────────────────────────────────────┘
                                     ▼
                       ┌─────────────────────────┐
                       │   SQLite database file  │
                       │     tmp/db.sqlite3      │
                       └─────────────────────────┘
```

**One server does two jobs:** it serves the compiled React files
(HTML/CSS/JS/images) AND answers JSON API calls under `/api/*`. That's why the
frontend can call `fetch('/api/products')` with no domain, no CORS issues, and
the session cookie just works.

---

## 2. 🌳 Folder Structure — what lives where

```
task03-adonis-react/
├── README.md                        ← setup + API reference
├── PROJECT-GUIDE.md                 ← you are here
│
├── server/                          ← BACKEND (AdonisJS 7, TypeScript)
│   ├── start/
│   │   ├── routes.ts                ← URL → controller mapping (the menu)
│   │   ├── kernel.ts                ← middleware pipeline definition
│   │   ├── env.ts                   ← typed env vars (PORT, HOST, APP_KEY…)
│   │   └── validator.ts             ← VineJS integration
│   │
│   ├── app/
│   │   ├── controllers/             ← REQUEST HANDLERS (one class per feature)
│   │   │   ├── products_controller.ts   → list/detail/reviews
│   │   │   ├── cart_controller.ts       → cart add/update/remove
│   │   │   ├── orders_controller.ts     → checkout + tracking
│   │   │   └── support_controller.ts    → support tickets
│   │   ├── models/                  ← LUCID MODELS = tables as classes
│   │   │   ├── product.ts  review.ts  cart_item.ts
│   │   │   ├── order.ts    order_item.ts  support_ticket.ts
│   │   ├── services/                ← REUSABLE BUSINESS LOGIC
│   │   │   ├── cart_service.ts          → totals, free-delivery math
│   │   │   └── order_tracking.ts        → live timeline logic
│   │   ├── validators/store.ts      ← input validation rules (VineJS)
│   │   └── exceptions/handler.ts    ← converts errors → clean JSON
│   │
│   ├── database/
│   │   ├── migrations/              ← 6 files that CREATE the tables
│   │   ├── seeders/product_seeder.ts← fills 17 demo products + reviews
│   │   └── schema.ts                ← AUTO-GENERATED typed columns from DB
│   │
│   ├── config/                      ← app/database/session/shield/cors/static
│   ├── public/                      ← REACT BUILD OUTPUT (served as static)
│   │   ├── index.html  assets/  images/
│   └── tmp/db.sqlite3               ← the actual SQLite database
│
└── client/                          ← FRONTEND (React + Vite)
    ├── index.html                   ← SPA shell (loads /src/main.tsx)
    ├── vite.config.ts               ← dev proxy + build → ../server/public
    ├── public/images/               ← 18 product/hero images (copied on build)
    └── src/
        ├── main.tsx                 ← app bootstrap (Redux Provider + router)
        ├── App.tsx                  ← routes + page layout (+ initial cart fetch)
        ├── api.ts                   ← axios re-exports + ₹formatters
        ├── styles.css               ← entire design system
        ├── lib/http.ts              ← AXIOS instance + interceptor + ApiError
        ├── app/
        │   ├── store.ts             ← RTK configureStore (cart + toast)
        │   └── hooks.ts             ← typed useAppDispatch/useAppSelector
        ├── features/
        │   ├── cart/cartSlice.ts    ← cart state + async thunks
        │   └── toast/toastSlice.ts  ← toasts + showToast thunk
        ├── components/              ← REUSABLE building blocks
        │   ├── Header.tsx  Footer.tsx
        │   ├── ProductCard.tsx  Stars.tsx  Media.tsx
        └── pages/                   ← ONE FILE PER SCREEN
            ├── Home.tsx             (/#/)
            ├── Shop.tsx             (/#/shop         — filters & sort)
            ├── ProductDetail.tsx    (/#/product/:id  — info + reviews)
            ├── CartPage.tsx         (/#/cart)
            ├── CheckoutPage.tsx     (/#/checkout)
            ├── OrdersPage.tsx       (/#/orders)
            ├── TrackPage.tsx        (/#/orders/:id   — live timeline)
            └── SupportPage.tsx      (/#/support      — FAQ + tickets)
```

---

## 3. 🔁 What happens when… (request life-cycles)

### 3.1 Opening the website

```
Browser → GET /
        → static middleware finds public/index.html → sends it
        → browser loads assets/index.js (the React app)
        → React boots: Redux <Provider store> + HashRouter
        → App immediately dispatches fetchCart() → GET /api/cart
              → session middleware reads "adonis-session" cookie
                 (or issues a NEW session id if first visit)
              → CartService.getView(sessionId) → {items:[], itemCount:0,...}
        → cart badge = hidden (0 items)
        → Home page calls GET /api/products → renders bestsellers
```

### 3.2 Browsing & filtering products (Shop page)

```
User types "ghee" / ticks a category / moves price range
   │
   ▼  React keeps ONE "filters" object in state
   ▼  useMemo builds the query-string:
        ?q=ghee&category=Staples+%26+Grocery&minPrice=100&sort=price-asc
   ▼  useEffect (with 250 ms debounce) calls:
        GET /api/products?...
   ▼
ProductsController.index()
   ├─ reads query params (request.qs())
   ├─ builds a Lucid query step by step:
   │     q          → WHERE name/description/tags ILIKE %ghee%
   │     category   → WHERE category IN (...)
   │     minPrice   → WHERE price >= 100
   │     minRating  → WHERE rating >= 4
   │     inStock=1  → WHERE stock > 0
   │     sort       → ORDER BY price DESC / rating / savings / name…
   ├─ runs it and ALSO queries all categories + price bounds
   │   (so the filter sidebar always shows the full range)
   └─ returns { count, categories, priceBounds, products[] }
   ▼
React re-renders ONLY the results grid → product cards appear
```

### 3.3 Adding to cart

```
Click "Add to Cart"
   → POST /api/cart  {productId: "masala-chai-250g", qty: 1}
   → CartController.store()
        1. find product by slug (404 if gone)
        2. clamp qty between 1–20
        3. look for existing cart row: session_id + product_id
        4. would exceed stock?
              YES → 409 {error:"Only N in stock.", cart} + cap row to stock
              NO  → existing? qty += add : create new row
        5. return CartService.getView()  (FRESH totals)
   → cartSlice reducer stores the fresh CartView → badge updates everywhere
   → toast "Added to cart 🛒"
```

**Where does the cart live?** In the `cart_items` **database table**, keyed by
`session_id`. That's why your cart survives page refresh — the session cookie
identifies you without any login.

### 3.4 Checkout → order → live tracking

```
CheckoutPage form → client-side validation (name, 10-digit phone, address)
   → POST /api/orders
   → OrdersController.store()
        1. checkoutValidator (VineJS) — 422 with field errors if invalid
        2. CartService.getView(session) — never trust client totals
        3. reject empty cart / any item qty > current stock (409)
        4. order number = "GFM-" + (10241 + existing order count)
        5. INSERT orders row  (customer, address snapshot, totals, payment)
        6. INSERT order_items rows (PRICE SNAPSHOT — safe against future edits)
        7. for each item: product.stock -= qty, product.sold += qty
        8. DELETE the session's cart_items
        9. return 201 { order: OrderTracking.present(order) }
   → React navigates to /#/orders/GFM-10241?placed=1 (success banner 🎉)
   → TrackPage polls GET /api/orders/GFM-10241 every 8 s
   → OrderTracking.present() computes status from elapsed time:
        0 s Placed → 30 s Confirmed → 90 s Packed
        → 180 s Out for Delivery → 300 s Delivered
   → steps light up live; auto-stops polling when Delivered
```

### 3.5 Review & support flows

```
POST /api/products/:id/reviews  {name, rating, comment}
   → reviewValidator → create review row (max 20 kept per product)
   → recompute average: rating = (rating×numReviews + new)/(numReviews+1)
   → save product, return updated product + the new review

POST /api/support  {name, email, subject, message}
   → ticketValidator → ticket "TKT-### + count", status Open
   → stores a canned auto-reply line, returned with 201
```

---

## 4. ⚙️ Backend — every file & function explained

### 4.1 `start/routes.ts` — the URL map
| Route | Goes to | Purpose |
|---|---|---|
| `GET /api` | inline | health check `{status:"ok"}` |
| `GET /api/products` | `ProductsController.index` | filtered/sorted catalogue |
| `GET /api/products/:id` | `ProductsController.show` | one product + reviews + related |
| `POST /api/products/:id/reviews` | `ProductsController.storeReview` | add review |
| `GET /api/cart` | `CartController.show` | view cart |
| `POST /api/cart` | `CartController.store` | add item |
| `PUT /api/cart/:productId` | `CartController.update` | change qty |
| `DELETE /api/cart/:productId` | `CartController.destroy` | remove item |
| `POST /api/orders` | `OrdersController.store` | **checkout** |
| `GET /api/orders` | `OrdersController.index` | my orders |
| `GET /api/orders/:id` | `OrdersController.show` | order + tracking |
| `GET/POST /api/support` | `SupportController.index/store` | tickets |

Controllers use lazy imports (`() => import(...)`) so they load on first request.

### 4.2 `start/kernel.ts` — the middleware pipeline
Every request passes through, IN ORDER:

```
force_json_response      → normalises Accept header to JSON (API-style errors)
container_bindings       → exposes request-scoped services
CORS                     → cross-origin rules (unused here: same origin)
STATIC                   → serves React build files; non-file URLs pass through
bodyparser               → parses JSON request bodies
SESSION                  → loads/creates session (sets adonis-session cookie)
shield                   → security headers (X-Frame disabled for the preview)
auth (optional)          → scaffolded staff auth, not used by the shop
```

### 4.3 `app/controllers/products_controller.ts`
| Function | What it does |
|---|---|
| `presentProduct(p)` | Shapes a DB row into the public JSON the frontend expects — parses `details`/`tags` JSON strings into arrays, rounds rating, renames `slug→id`, `description→desc`. Keeps DB internals out of the API. |
| `presentReview(r)` | Shapes a review row: id, name, rating, comment, `createdAt→date (YYYY-MM-DD)`. |
| `index({request})` | **The filter/sort engine.** Reads query params, chains Lucid `where` clauses (search via `whereILike` on name/description/tags, category `whereIn`, price range, rating floor, stock>0), applies one of 5 sorts, then also returns `categories` + `priceBounds` (from ALL products, so the sidebar never collapses). |
| `show({params,response})` | Finds product by slug, `preload`s its 20 newest reviews, fetches 4 related products from same category. 404 if missing. |
| `storeReview(...)` | Validates input, clamps rating 1–5, creates review through the product relation, **recalculates weighted average** `rating = (avg×n + new)/(n+1)`, increments `numReviews`, returns updated product. |

### 4.4 `app/controllers/cart_controller.ts`
| Function | What it does |
|---|---|
| `show` | Returns `CartService.getView(sessionId)`. |
| `store` | Adds item: validates product exists, clamps qty 1–20, checks stock (409 + capped cart if insufficient), increments existing row or creates one. Returns fresh cart. |
| `update` | Sets exact qty for a line; qty ≤ 0 deletes the line; qty clamped to stock. |
| `destroy` | Deletes the cart line. Always returns the fresh cart so the UI stays in sync. |

### 4.5 `app/services/cart_service.ts`
| Function | What it does |
|---|---|
| `getView(sessionId)` | THE cart calculator: loads `cart_items` rows joined to products (`preload`), builds line totals, `subtotal`, `itemCount`, `deliveryFee` (₹40, FREE if subtotal ≥ ₹499), `total`, and `amountToFreeDelivery` (drives the progress bar). Used by cart AND checkout — single source of truth for money math. |

### 4.6 `app/controllers/orders_controller.ts`
| Function | What it does |
|---|---|
| `store` | **Checkout** (the biggest function): validate input → build cart server-side → guard empty cart & stock races → mint order number → insert order + item snapshots → decrement stock / bump popularity → clear cart → return 201 with tracked view. |
| `index` | This session's orders, newest first, each enriched with live status. |
| `show` | One order (scoped to session so you can't see strangers' orders) + timeline. |

### 4.7 `app/services/order_tracking.ts`
| Function | What it does |
|---|---|
| `STATUS_STEPS` | The 5 stages `(label, description, offsetSec)`. |
| `present(order)` | Computes current step from elapsed seconds since `createdAt`, returns the API-facing order: customer, items, totals, `status/statusKey`, and per-step `done/current/time` so the UI can draw the timeline AND show timestamps of completed steps. |

### 4.8 `app/controllers/support_controller.ts`
| Function | What it does |
|---|---|
| `store` | Validates, mints `TKT-121`-style numbers from the count, stores ticket + auto-reply, returns 201. |
| `index` | This session's tickets, newest first. |

### 4.9 `app/validators/store.ts` (VineJS)
- `reviewValidator` — name 2–40 chars, number rating 1–5, comment 5–500.
- `checkoutValidator` — name, **phone regex `^[6-9]\d{9}$`**, address ≥ 10 chars, optional landmark/notes, payment ∈ `[cod, upi]`.
- `ticketValidator` — name, valid email, subject ∈ fixed list, message ≥ 10.
Failed rules → `422` with per-field messages (shown under form fields by React).

### 4.10 `app/models/*` (Lucid ORM)
Models extend auto-generated schema classes (from `database/schema.ts`) and add **relations**:

```
Product ─hasMany─► Review          Review ─belongsTo─► Product
CartItem ─belongsTo─► Product      Order ─hasMany─► OrderItem
OrderItem ─belongsTo─► Order       SupportTicket (plain)
```

### 4.11 `database/` layer
- **migrations/** — 6 files; each has `up()` (create table with columns, FKs `ON DELETE CASCADE`, indexes, unique constraints) and `down()` (drop).
- **schema.ts** — regenerated on every `migration:run`; gives TypeScript exact column names/types.
- **seeders/product_seeder.ts → `run()`** — skips if products exist, else inserts the 17-item catalogue (details/tags JSON-stringified) and their seed reviews.

### 4.12 Money & status constants (single sources of truth)
| Constant | Value | Used by |
|---|---|---|
| `FREE_DELIVERY_ABOVE` | ₹499 | CartService → progress bar + fee |
| `DELIVERY_FEE` | ₹40 | CartService |
| status offsets | 0/30/90/180/300 s | OrderTracking → timeline |

---

## 5. 🖥️ Frontend — every file, page & function

### 5.1 Boot chain
```
main.tsx → renders:
   <Provider store={store}>   (Redux Toolkit — cart + toast slices)
     <HashRouter>             (URLs like /#/shop survive server-side; no 404s)
       <App/>                 (top strip + Header + routed <main> + Footer + <Toasts/>)
   App boot effect → dispatch(fetchCart()) → header badge count
   Any component: useAppSelector(state.cart) / dispatch(thunks) — no prop drilling
```

### 5.2 `src/lib/http.ts` + `src/api.ts` — the AXIOS layer
| Function | Purpose |
|---|---|
| `http` | Pre-configured **axios instance**: baseURL `/`, JSON headers, `withCredentials` (session cookie), 15 s timeout. |
| response interceptor | Converts every HTTP failure — including VineJS `{errors:[{message…}]}` 422s — into a typed `ApiError` with a friendly message, before it reaches your code. |
| `httpGet/httpPost/httpPut/httpDelete()` | Typed verb helpers used by the Redux thunks. |
| `api(path, options)` | Fetch-style convenience wrapper over the same axios instance, used by pages for one-off reads. |
| `inr` | `Intl.NumberFormat` → `₹1,234` formatting. |
| `orderDate(ts)` | Date helper → "12 Aug, 4:30 pm". |
| `CAT_EMOJI`, `STATUS_STEPS_ICONS`, `statusClass()` | Display mappings (category/emoji, timeline icons, chip CSS classes). |

### 5.3 Redux store (global state) — Redux Toolkit
**`app/store.ts`** — single `configureStore` with two slices; **`app/hooks.ts`** exports typed `useAppDispatch` / `useAppSelector` (`useDispatch.withTypes<AppDispatch>()`).

**`features/cart/cartSlice.ts`**
| Piece | Purpose |
|---|---|
| `fetchCart` thunk | GET /api/cart on app start → badge count. |
| `addToCart` thunk | POST add → stores returned cart → success toast; on 409 it dispatches `cartLoaded` with the stock-capped cart + error toast. |
| `setCartQty` thunk | PUT (or DELETE when ≤ 0) → fresh totals. |
| `cartLoaded` / `clearLocalCart` | Sync a server cart · reset locally after checkout. |
| selectors | `selectCart`, `selectCartLoaded`, `selectCartItemCount` |

**`features/toast/toastSlice.ts`** — `showToast(message, type)` thunk adds an item and
auto-dispatches `removeToast(id)` after 3 s. Rendered by `<Toasts/>`, fixed at
bottom-center.

### 5.4 Reusable components
| Component | Purpose |
|---|---|
| `Header.tsx` | Logo, nav links highlighted by route (`NavLink`), cart button with live `itemCount` badge (hidden when 0). |
| `Footer.tsx` | Store address/hours/contact. |
| `ProductCard.tsx` | The grid card: discount badge (% off), low-stock/out-of-stock badges, category, name, unit, star row, price + strikethrough MRP, Add-to-Cart button (`stopPropagation` so the card click navigates but the button adds). |
| `Stars.tsx` | Visual rating: grey ★★★★★ with a gold overlay clipped to `rating/5` width. |
| `Media.tsx` | Product image with **graceful fallback**: if the image fails to load, it hides itself revealing the emoji tile behind. |

### 5.5 Pages — what each screen does

#### 🏠 `Home.tsx`  — `/#/`
Fetches `/api/products` once → hero with working search box (navigates to
shop with `?q=`), 5 category cards (navigate pre-filtered), top-8 bestseller
cards, 4 trust perks. Hero image hides itself if missing.

#### 🛍️ `Shop.tsx` — `/#/shop`
- **State:** one `filters` object `{q, categories:Set, min, max, rating, inStock, sort}` initialised from URL params (so hero-search and category cards deep-link here).
- **Effect chain:** filters → `useMemo` query-string → debounced `useEffect` fetch → results grid. Stale responses are cancelled.
- **UI:** sidebar (category checkboxes, price min/max, rating radios, in-stock, clear-all) + toolbar (mobile filter toggle, live search, sort select) + result count + grid with a custom empty state.

#### 📄 `ProductDetail.tsx` — `/#/product/:id`
Resets and refetches when the id changes. Left: large photo (emoji fallback).
Right: rating summary, price/off %, stock status (green/amber/red), description,
detail bullets, **quantity stepper + dynamic Add-to-Cart button** (shows total
price × qty, disabled when out of stock), delivery perks. Below: review summary
(big average + stars), review list, and a **write-a-review form with star
picker** — submitting re-fetches so rating/count update live. Ends with
related products.

#### 🛒 `CartPage.tsx` — `/#/cart`
Reads global cart. Empty → friendly empty state. Else: per-line thumbnail,
name, unit price, qty stepper (disable `+` at stock limit), line total, remove.
Sidebar: **MRP savings chip**, **free-delivery progress bar** ("add ₹X more"),
subtotal/fee/total, checkout CTA, continue-shopping link.

#### 💳 `CheckoutPage.tsx` — `/#/checkout`
Guards empty cart. Left form: name/phone/address/landmark/notes with inline
per-field validation (red border + message), **payment radio cards** (COD /
UPI) styled as selectable tiles. Right: order summary. `placeOrder()`:
client-validate → POST → on success clear badge → toast → navigate to the
tracking page with `?placed=1` trigger for the 🎉 banner. Re-enables the
button on failure.

#### 📦 `OrdersPage.tsx` — `/#/orders`
Lists this session's orders: number, status chip (color-coded), time, item
chips (`+N more`), total + payment method, "Track order". **Self-refresh every
10 s** while any order is undelivered (cleanup on unmount). Demo note explains
the accelerated timeline.

#### 🛵 `TrackPage.tsx` — `/#/orders/:id`
The star feature. Optional success banner (`?placed=1`). Header: order id +
live chip. **Vertical timeline**: 5 steps with icons, connecting line turns
green as steps complete, current step pulses, done steps show timestamps.
Right column: delivery details, payment, full item bill. **Polls every 8 s**
until delivered, then stops and offers "Order again". Unknown id → not-found state.

#### 🎧 `SupportPage.tsx` — `/#/support`
Two columns: FAQ accordion (native `<details>`) + "My tickets" list (id, Open
chip, subject/message, auto-reply, time) — and the ticket form (name/email/
subject select/message) with the same inline validation pattern, toast on
`TKT-xxx` created, and instant ticket-list refresh.

---

## 6. 🗄️ Database tables (quick reference)

```
products        id · slug · name · category · price · mrp · unit · emoji
                image · description · details · tags · stock · sold
                featured · rating · num_reviews · timestamps
reviews         id · product_id(FK→products, cascade) · name · rating · comment
cart_items      id · session_id · product_id(FK, cascade) · qty
                UNIQUE(session_id, product_id)
orders          id · order_number · session_id · customer_name · phone
                address · landmark · notes · payment
                subtotal · delivery_fee · total
order_items     id · order_id(FK, cascade) · name · unit · emoji · image
                price · qty · line_total        (purchase-time snapshot)
support_tickets id · ticket_number · session_id · name · email
                subject · message · status · reply
(+ starter-kit: users, auth_access_tokens for the included auth API)
```

---

## 7. ⚡ The 5 key design decisions (why it works this way)

1. **One port, one origin** — React built into `server/public`, Adonis serves
   both UI and API → no CORS, cookies "just work", single preview link.
2. **Session cart, no login needed** — a cookie session ties cart/orders/tickets
   to the visitor; a real store would swap in accounts later (auth scaffold included).
3. **Server is the single source of truth for money & stock** — the client never
   sends prices; totals are always recomputed from DB rows at checkout.
4. **Snapshots in `order_items`** — orders keep name/price at purchase time, so
   later catalogue edits never corrupt history.
5. **Time-based tracking demo** — statuses are computed from `createdAt + offsets`,
   letting you watch the full delivery lifecycle live without a staff panel.
