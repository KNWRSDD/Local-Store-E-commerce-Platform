import Product from '#models/product'
import { BaseSeeder } from '@adonisjs/lucid/seeders'

type SeedReview = { name: string; rating: number; comment: string }

type SeedProduct = {
  slug: string
  name: string
  category: string
  price: number
  mrp: number
  unit: string
  emoji: string
  image: string | null
  description: string
  details: string[]
  tags: string[]
  stock: number
  sold: number
  featured: boolean
  rating: number
  numReviews: number
  reviews: SeedReview[]
}

const CATALOGUE: SeedProduct[] = [
  {
    slug: 'basmati-rice-5kg', name: 'Aged Basmati Rice', category: 'Staples & Grocery',
    price: 549, mrp: 699, unit: '5 kg bag', emoji: '🍚', image: '/images/basmati-rice-5kg.jpg',
    description: 'Premium aged basmati rice with extra-long grains and a rich aroma. Perfect for biryani, pulao and everyday meals.',
    details: ['Aged for 24 months', 'Extra-long grain', 'Naturally aromatic', 'Cleaned & sortex graded'],
    tags: ['rice', 'basmati', 'biryani', 'grain', 'pulao'], stock: 24, sold: 412, featured: true,
    rating: 4.6, numReviews: 128,
    reviews: [
      { name: 'Neha Sharma', rating: 5, comment: 'Grains are long and super aromatic — my biryani turned out amazing.' },
      { name: 'Rohit Khatri', rating: 4, comment: 'Good quality rice, cooks fluffy. Delivery was within the hour.' },
    ],
  },
  {
    slug: 'whole-wheat-atta-10kg', name: 'Chakki Fresh Whole Wheat Atta', category: 'Staples & Grocery',
    price: 415, mrp: 499, unit: '10 kg pack', emoji: '🌾', image: '/images/whole-wheat-atta-10kg.jpg',
    description: '100% whole wheat atta, ground slowly to retain fibre and nutrients. Makes soft, fluffy rotis that stay fresh for hours.',
    details: ['100% whole wheat', 'Chakki ground', 'High in fibre', 'No maida blended'],
    tags: ['atta', 'wheat', 'flour', 'roti', 'chakki'], stock: 18, sold: 365, featured: true,
    rating: 4.5, numReviews: 96,
    reviews: [
      { name: 'Pooja Verma', rating: 5, comment: 'Rotis come out very soft. Regular purchase for our home now.' },
      { name: 'Ankit Tyagi', rating: 4, comment: 'Fresh stock, well packed. Good value for 10 kg.' },
    ],
  },
  {
    slug: 'toor-dal-1kg', name: 'Arhar / Toor Dal (Unpolished)', category: 'Staples & Grocery',
    price: 168, mrp: 189, unit: '1 kg pack', emoji: '🥣', image: '/images/toor-dal-1kg.jpg',
    description: 'Unpolished arhar dal that cooks quickly and tastes homely. A protein-rich staple for everyday dal tadka.',
    details: ['Unpolished — no oil or water coating', 'High in protein', 'Cooks fast', 'Uniform grain size'],
    tags: ['dal', 'toor', 'arhar', 'pulses', 'protein'], stock: 40, sold: 289, featured: false,
    rating: 4.4, numReviews: 74,
    reviews: [
      { name: 'Sunita Devi', rating: 5, comment: 'Dal is clean, no stones. Cooks in two whistles.' },
    ],
  },
  {
    slug: 'desi-ghee-1l', name: 'A2 Desi Cow Ghee', category: 'Staples & Grocery',
    price: 640, mrp: 720, unit: '1 L jar', emoji: '🧈', image: '/images/desi-ghee-1l.jpg',
    description: 'Slow-simmered A2 desi cow ghee made the traditional way. Grainy texture, golden colour and an aroma that fills the kitchen.',
    details: ['Traditional bilona method', 'Grainy (danedaar) texture', 'Made from A2 milk', 'Glass jar packed'],
    tags: ['ghee', 'a2', 'desi', 'cow', 'bilona'], stock: 12, sold: 198, featured: true,
    rating: 4.8, numReviews: 152,
    reviews: [
      { name: 'Kavita Rana', rating: 5, comment: 'Smells just like nani ka ghar. Worth every rupee.' },
      { name: 'Mohd. Salman', rating: 5, comment: 'Pure danedaar ghee. Ordering second jar now.' },
    ],
  },
  {
    slug: 'mustard-oil-1l', name: 'Cold-Pressed Mustard Oil', category: 'Staples & Grocery',
    price: 215, mrp: 250, unit: '1 L bottle', emoji: '🍶', image: '/images/mustard-oil-1l.jpg',
    description: 'Kachi ghani cold-pressed mustard oil with the classic pungent kick. Ideal for tadka, pickles and everyday UP-style cooking.',
    details: ['Kachi ghani (cold pressed)', 'Naturally pungent', 'No blending or additives', 'Great for pickles & tadka'],
    tags: ['oil', 'mustard', 'sarson', 'cooking', 'kachi ghani'], stock: 30, sold: 243, featured: false,
    rating: 4.3, numReviews: 61,
    reviews: [
      { name: 'Rakesh Yadav', rating: 4, comment: 'Proper jhanjh of real sarson. Good for parathas.' },
    ],
  },
  {
    slug: 'full-cream-milk-1l', name: 'Full Cream Milk', category: 'Dairy & Fresh',
    price: 66, mrp: 70, unit: '1 L pouch', emoji: '🥛', image: '/images/full-cream-milk-1l.jpg',
    description: 'Farm-fresh full cream milk, pasteurised and delivered chilled every morning. Thick malai guaranteed.',
    details: ['Full cream — 6% fat', 'Pasteurised & chilled', 'Sourced from local farms', 'Delivered before 8 AM'],
    tags: ['milk', 'dairy', 'cream', 'malai', 'fresh'], stock: 50, sold: 680, featured: true,
    rating: 4.5, numReviews: 210,
    reviews: [
      { name: 'Deepali Gupta', rating: 5, comment: 'Thick malai on boiling. My chai tastes better with this milk.' },
      { name: 'Vikas Chauhan', rating: 4, comment: 'Always fresh, never expired stock. Reliable daily order.' },
    ],
  },
  {
    slug: 'fresh-paneer-200g', name: 'Fresh Malai Paneer', category: 'Dairy & Fresh',
    price: 92, mrp: 105, unit: '200 g pack', emoji: '🧀', image: '/images/fresh-paneer-200g.jpg',
    description: 'Soft, melt-in-the-mouth malai paneer made fresh every morning from full-cream milk. Perfect for paneer butter masala.',
    details: ['Made fresh daily', 'No preservatives', 'Rich malai taste', 'Soft, non-rubbery texture'],
    tags: ['paneer', 'dairy', 'cheese', 'malai', 'fresh'], stock: 15, sold: 176, featured: false,
    rating: 4.6, numReviews: 88,
    reviews: [
      { name: 'Reena Joshi', rating: 5, comment: 'Softest paneer I have bought locally. Kids loved it.' },
    ],
  },
  {
    slug: 'brown-bread-400g', name: 'Whole Wheat Brown Bread', category: 'Dairy & Fresh',
    price: 45, mrp: 50, unit: '400 g loaf', emoji: '🍞', image: '/images/brown-bread-400g.jpg',
    description: 'Soft whole wheat brown bread baked fresh at the local bakery every morning. High fibre, great for sandwiches and toast.',
    details: ['100% whole wheat', 'Baked fresh daily', 'High in fibre', 'No artificial colour'],
    tags: ['bread', 'brown', 'bakery', 'toast', 'wheat'], stock: 20, sold: 154, featured: false,
    rating: 4.2, numReviews: 45,
    reviews: [],
  },
  {
    slug: 'bananas-1dz', name: 'Fresh Robusta Bananas', category: 'Dairy & Fresh',
    price: 60, mrp: 72, unit: '1 dozen', emoji: '🍌', image: '/images/bananas-1dz.jpg',
    description: 'Naturally ripened robusta bananas — sweet, spotless and ready to eat. A healthy everyday fruit for the whole family.',
    details: ['Naturally ripened', 'No chemical ripening agents', 'Rich in potassium', 'Handpicked bunches'],
    tags: ['banana', 'fruit', 'fresh', 'kela', 'healthy'], stock: 25, sold: 331, featured: false,
    rating: 4.4, numReviews: 97,
    reviews: [
      { name: 'Farhan Ali', rating: 4, comment: 'All bananas were yellow and firm, none damaged. Good packing.' },
    ],
  },
  {
    slug: 'masala-chai-250g', name: 'Kadak Masala Chai', category: 'Snacks & Beverages',
    price: 145, mrp: 170, unit: '250 g pack', emoji: '🍵', image: '/images/masala-chai-250g.jpg',
    description: 'Strong CTC chai blended with real spices — elaichi, adrak, dalchini and laung. One cup and you are wide awake.',
    details: ['Real ground spices', 'Strong kadak CTC base', 'No artificial flavour', 'Resealable pack'],
    tags: ['chai', 'tea', 'masala', 'beverage', 'kadak'], stock: 35, sold: 402, featured: true,
    rating: 4.7, numReviews: 164,
    reviews: [
      { name: 'Amit Saxena', rating: 5, comment: 'Proper dhaba-style kadak chai. Masala is perfectly balanced.' },
      { name: 'Shalini Kapoor', rating: 5, comment: 'No need to add extra adrak or elaichi. Very convenient.' },
    ],
  },
  {
    slug: 'instant-noodles-12pk', name: 'Instant Masala Noodles (Pack of 12)', category: 'Snacks & Beverages',
    price: 168, mrp: 192, unit: '12 × 70 g', emoji: '🍜', image: '/images/instant-noodles-12pk.jpg',
    description: "Everyone's favourite masala instant noodles in a family value pack. Ready in 2 minutes — the ultimate rainy-day snack.",
    details: ['Pack of 12', 'Cooks in 2 minutes', 'Masala tastemaker inside', 'Family value pack'],
    tags: ['noodles', 'instant', 'masala', 'snack', 'maggie'], stock: 28, sold: 512, featured: true,
    rating: 4.5, numReviews: 231,
    reviews: [
      { name: 'Ishan Bansal', rating: 5, comment: 'Cheaper than the local market rate. Stocked up for the month.' },
    ],
  },
  {
    slug: 'glucose-biscuits-family', name: 'Glucose Biscuits Family Pack', category: 'Snacks & Beverages',
    price: 60, mrp: 75, unit: '600 g pack', emoji: '🍪', image: '/images/glucose-biscuits-family.jpg',
    description: 'Classic crunchy glucose biscuits in a big family pack. The undefeated partner of cutting chai since forever.',
    details: ['Family value pack', 'Crunchy & light', 'Perfect with chai', 'Energy rich'],
    tags: ['biscuits', 'glucose', 'cookie', 'chai', 'snack'], stock: 45, sold: 388, featured: false,
    rating: 4.3, numReviews: 112,
    reviews: [],
  },
  {
    slug: 'namkeen-mix-400g', name: 'Roasted Navratan Namkeen Mix', category: 'Snacks & Beverages',
    price: 110, mrp: 130, unit: '400 g pack', emoji: '🥜', image: '/images/namkeen-mix-400g.png',
    description: 'Crunchy navratan mix of roasted peanuts, dals, sev and spices. Roasted, not fried — the perfect tea-time munch.',
    details: ['Roasted, not fried', 'Peanuts, dals & crisp sev', 'Tangy masala flavour', 'Tea-time favourite'],
    tags: ['namkeen', 'snack', 'mixture', 'roasted', 'navratan'], stock: 22, sold: 145, featured: false,
    rating: 4.1, numReviews: 38,
    reviews: [
      { name: 'Manoj Kumar', rating: 4, comment: 'Not oily at all. Tangy and crunchy — good with evening chai.' },
    ],
  },
  {
    slug: 'coconut-hair-oil-250ml', name: 'Pure Coconut Hair Oil', category: 'Personal Care',
    price: 120, mrp: 145, unit: '250 ml bottle', emoji: '🥥', image: '/images/coconut-hair-oil-250ml.jpg',
    description: '100% pure cold-pressed coconut oil for strong, shiny hair. Light, non-sticky and doubles up as a skin moisturiser.',
    details: ['100% pure coconut', 'Cold pressed', 'Light & non-sticky', 'Good for hair & skin'],
    tags: ['coconut', 'oil', 'hair', 'personal care'], stock: 26, sold: 87, featured: false,
    rating: 4.4, numReviews: 52,
    reviews: [],
  },
  {
    slug: 'neem-soap-4pk', name: 'Neem & Tulsi Herbal Soap (Pack of 4)', category: 'Personal Care',
    price: 140, mrp: 176, unit: '4 × 100 g', emoji: '🧼', image: '/images/neem-soap-4pk.jpg',
    description: 'Herbal bathing bars with neem and tulsi extracts. Naturally anti-bacterial with a fresh, earthy fragrance.',
    details: ['Neem & tulsi extracts', 'Naturally anti-bacterial', 'Pack of 4', 'Suitable for all skin types'],
    tags: ['soap', 'neem', 'tulsi', 'herbal', 'bath'], stock: 32, sold: 119, featured: false,
    rating: 4.2, numReviews: 44,
    reviews: [
      { name: 'Nidhi Arora', rating: 4, comment: 'Mild fragrance, no dryness after use. Good family soap.' },
    ],
  },
  {
    slug: 'detergent-2kg', name: 'Detergent Powder (Top Load)', category: 'Household Essentials',
    price: 230, mrp: 285, unit: '2 kg box', emoji: '🧺', image: '/images/detergent-2kg.jpg',
    description: 'High-foam detergent formulated for top-load machines. Tough on stains, gentle on clothes, with a fresh fragrance.',
    details: ['Top-load machine formula', 'Tough on stains', 'Fresh fragrance', '2 kg family pack'],
    tags: ['detergent', 'washing', 'laundry', 'powder', 'household'], stock: 16, sold: 132, featured: false,
    rating: 4.3, numReviews: 67,
    reviews: [],
  },
  {
    slug: 'dishwash-gel-500ml', name: 'Lemon Dishwash Gel', category: 'Household Essentials',
    price: 99, mrp: 125, unit: '500 ml bottle', emoji: '🍋', image: '/images/dishwash-gel-500ml.jpg',
    description: 'Lemon-powered dishwash gel that cuts grease in one drop. Tough on kadhai stains, gentle on hands.',
    details: ['Active lemon formula', 'Cuts grease fast', 'Gentle on hands', 'Only a drop needed'],
    tags: ['dishwash', 'gel', 'lemon', 'kitchen', 'cleaning'], stock: 34, sold: 201, featured: false,
    rating: 4.4, numReviews: 83,
    reviews: [
      { name: 'Seema Rathi', rating: 5, comment: 'One small drop cleans the whole kadhai. Lasts really long.' },
    ],
  },
]

export default class ProductSeeder extends BaseSeeder {
  async run() {
    const [{ $extras }] = await Product.query().count('* as total')
    if (Number($extras.total) > 0) {
      console.log('  ⏭  products already seeded, skipping')
      return
    }

    for (const item of CATALOGUE) {
      const { reviews, ...data } = item
      const product = await Product.create({
        ...data,
        details: JSON.stringify(data.details),
        tags: JSON.stringify(data.tags),
      })
      if (reviews.length) {
        await product.related('reviews').createMany(reviews)
      }
    }
    console.log(`  ✅ seeded ${CATALOGUE.length} products with reviews`)
  }
}
