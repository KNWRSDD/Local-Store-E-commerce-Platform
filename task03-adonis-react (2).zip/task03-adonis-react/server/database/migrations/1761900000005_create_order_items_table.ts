import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'order_items'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').notNullable()
      table
        .integer('order_id')
        .unsigned()
        .notNullable()
        .references('orders.id')
        .onDelete('CASCADE')
      table.string('name').notNullable()
      table.string('unit').notNullable()
      table.string('emoji').notNullable().defaultTo('🛍️')
      table.string('image').nullable()
      table.integer('price').notNullable()
      table.integer('qty').notNullable()
      table.integer('line_total').notNullable()

      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}
