import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'products'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').notNullable()
      table.string('slug').notNullable().unique()
      table.string('name').notNullable()
      table.string('category').notNullable()
      table.integer('price').notNullable()
      table.integer('mrp').notNullable()
      table.string('unit').notNullable()
      table.string('emoji').notNullable().defaultTo('🛍️')
      table.string('image').nullable()
      table.text('description').notNullable()
      table.text('details').notNullable().defaultTo('[]')
      table.text('tags').notNullable().defaultTo('[]')
      table.integer('stock').notNullable().defaultTo(0)
      table.integer('sold').notNullable().defaultTo(0)
      table.boolean('featured').notNullable().defaultTo(false)
      table.float('rating').notNullable().defaultTo(0)
      table.integer('num_reviews').notNullable().defaultTo(0)

      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}
