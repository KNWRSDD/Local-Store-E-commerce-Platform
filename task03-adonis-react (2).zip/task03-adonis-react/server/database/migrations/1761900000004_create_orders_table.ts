import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'orders'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').notNullable()
      table.string('order_number').notNullable().unique()
      table.string('session_id').notNullable().index()
      table.string('customer_name').notNullable()
      table.string('phone').notNullable()
      table.text('address').notNullable()
      table.string('landmark').nullable()
      table.text('notes').nullable()
      table.string('payment').notNullable()
      table.integer('subtotal').notNullable()
      table.integer('delivery_fee').notNullable()
      table.integer('total').notNullable()

      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}
