import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'support_tickets'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').notNullable()
      table.string('ticket_number').notNullable().unique()
      table.string('session_id').notNullable().index()
      table.string('name').notNullable()
      table.string('email').notNullable()
      table.string('subject').notNullable()
      table.text('message').notNullable()
      table.string('status').notNullable().defaultTo('Open')
      table.text('reply').nullable()

      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}
