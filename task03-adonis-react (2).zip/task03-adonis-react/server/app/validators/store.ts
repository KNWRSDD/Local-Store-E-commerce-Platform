import vine from '@vinejs/vine'

/**
 * POST /api/products/:id/reviews
 */
export const reviewValidator = vine.compile(
  vine.object({
    name: vine.string().trim().minLength(2).maxLength(40),
    rating: vine.number().min(1).max(5),
    comment: vine.string().trim().minLength(5).maxLength(500),
  })
)

/**
 * POST /api/orders
 */
export const checkoutValidator = vine.compile(
  vine.object({
    name: vine.string().trim().minLength(2).maxLength(60),
    phone: vine.string().trim().regex(/^[6-9]\d{9}$/),
    address: vine.string().trim().minLength(10).maxLength(300),
    landmark: vine.string().trim().maxLength(80).optional(),
    notes: vine.string().trim().maxLength(300).optional(),
    payment: vine.enum(['cod', 'upi'] as const),
  })
)

/**
 * POST /api/support
 */
export const ticketValidator = vine.compile(
  vine.object({
    name: vine.string().trim().minLength(2).maxLength(60),
    email: vine.string().trim().email().maxLength(120),
    subject: vine.enum([
      'Order issue',
      'Damaged / missing item',
      'Refund',
      'Delivery feedback',
      'Product suggestion',
      'Other',
    ] as const),
    message: vine.string().trim().minLength(10).maxLength(800),
  })
)
