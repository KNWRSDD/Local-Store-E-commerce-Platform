import { SupportTicketSchema } from '#database/schema'

export default class SupportTicket extends SupportTicketSchema {}
