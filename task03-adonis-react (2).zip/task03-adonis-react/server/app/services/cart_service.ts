import CartItem from '#models/cart_item'

export const FREE_DELIVERY_ABOVE = 499
export const DELIVERY_FEE = 40

/**
 * Builds the full cart view (items + totals) for a session.
 */
export default class CartService {
  static async getView(sessionId: string) {
    const rows = await CartItem.query()
      .where('sessionId', sessionId)
      .preload('product')
      .orderBy('id', 'asc')

    const items = rows
      .filter((row) => row.product && row.qty > 0)
      .map((row) => ({
        productId: row.product.slug,
        name: row.product.name,
        unit: row.product.unit,
        emoji: row.product.emoji,
        image: row.product.image,
        price: row.product.price,
        mrp: row.product.mrp,
        qty: row.qty,
        stock: row.product.stock,
        lineTotal: row.product.price * row.qty,
      }))

    const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0)
    const deliveryFee = subtotal === 0 || subtotal >= FREE_DELIVERY_ABOVE ? 0 : DELIVERY_FEE

    return {
      items,
      itemCount: items.reduce((sum, item) => sum + item.qty, 0),
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee,
      freeDeliveryAbove: FREE_DELIVERY_ABOVE,
      amountToFreeDelivery: Math.max(0, FREE_DELIVERY_ABOVE - subtotal),
    }
  }
}
