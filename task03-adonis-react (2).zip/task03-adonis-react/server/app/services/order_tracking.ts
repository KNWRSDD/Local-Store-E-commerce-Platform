import type Order from '#models/order'

/**
 * Order-tracking timeline. Statuses auto-advance with elapsed time so the
 * tracking page demos the full lifecycle live (a real store would update
 * these manually from a staff panel).
 */
export const STATUS_STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'We have received your order.', offsetSec: 0 },
  { key: 'confirmed', label: 'Confirmed', desc: 'The store has confirmed your order.', offsetSec: 30 },
  { key: 'packed', label: 'Packed', desc: 'Your items are packed and ready.', offsetSec: 90 },
  { key: 'out', label: 'Out for Delivery', desc: 'Delivery partner is on the way.', offsetSec: 180 },
  { key: 'delivered', label: 'Delivered', desc: 'Order delivered. Enjoy!', offsetSec: 300 },
] as const

export default class OrderTracking {
  static present(order: Order) {
    const createdMs = order.createdAt.toMillis()
    const elapsedSec = (Date.now() - createdMs) / 1000
    let current = 0
    STATUS_STEPS.forEach((step, index) => {
      if (elapsedSec >= step.offsetSec) current = index
    })

    return {
      id: order.orderNumber,
      customer: {
        name: order.customerName,
        phone: order.phone,
        address: order.address,
        landmark: order.landmark,
        notes: order.notes,
      },
      items: (order.items ?? []).map((item) => ({
        name: item.name,
        unit: item.unit,
        emoji: item.emoji,
        image: item.image,
        price: item.price,
        qty: item.qty,
        lineTotal: item.lineTotal,
      })),
      subtotal: order.subtotal,
      deliveryFee: order.deliveryFee,
      total: order.total,
      payment: order.payment,
      paymentLabel: order.payment === 'cod' ? 'Cash on Delivery' : 'UPI (on delivery)',
      createdAt: createdMs,
      status: STATUS_STEPS[current].label,
      statusKey: STATUS_STEPS[current].key,
      timeline: STATUS_STEPS.map((step, index) => ({
        key: step.key,
        label: step.label,
        desc: step.desc,
        done: index <= current,
        current: index === current,
        time: createdMs + step.offsetSec * 1000,
      })),
    }
  }
}
