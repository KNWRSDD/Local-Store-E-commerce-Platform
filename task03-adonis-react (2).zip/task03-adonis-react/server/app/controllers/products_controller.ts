import Product from '#models/product'
import type ProductType from '#models/product'
import type Review from '#models/review'
import { reviewValidator } from '#validators/store'
import type { HttpContext } from '@adonisjs/core/http'

function safeList(json: string): string[] {
  try {
    const parsed = JSON.parse(json)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export function presentProduct(p: ProductType) {
  return {
    id: p.slug,
    name: p.name,
    category: p.category,
    price: p.price,
    mrp: p.mrp,
    unit: p.unit,
    emoji: p.emoji,
    image: p.image,
    desc: p.description,
    details: safeList(p.details),
    tags: safeList(p.tags),
    stock: p.stock,
    sold: p.sold,
    featured: p.featured,
    rating: Math.round(p.rating * 100) / 100,
    numReviews: p.numReviews,
  }
}

export function presentReview(r: Review) {
  return {
    id: r.id,
    name: r.name,
    rating: r.rating,
    comment: r.comment,
    date: r.createdAt.toISODate(),
  }
}

export default class ProductsController {
  /**
   * GET /api/products?q=&category=&minPrice=&maxPrice=&minRating=&inStock=&sort=
   */
  async index({ request }: HttpContext) {
    const qs = request.qs()
    const query = Product.query()

    if (qs.q) {
      const needle = String(qs.q).toLowerCase().trim()
      query.where((builder) => {
        builder
          .whereILike('name', `%${needle}%`)
          .orWhereILike('description', `%${needle}%`)
          .orWhereILike('tags', `%${needle}%`)
      })
    }

    if (qs.category) {
      const categories = String(qs.category).split(',').filter(Boolean)
      if (categories.length) query.whereIn('category', categories)
    }
    if (Number.isFinite(Number(qs.minPrice)) && qs.minPrice !== '' && qs.minPrice !== undefined) {
      query.where('price', '>=', Number(qs.minPrice))
    }
    if (Number.isFinite(Number(qs.maxPrice)) && qs.maxPrice !== '' && qs.maxPrice !== undefined) {
      query.where('price', '<=', Number(qs.maxPrice))
    }
    if (Number(qs.minRating) > 0) query.where('rating', '>=', Number(qs.minRating))
    if (qs.inStock === '1') query.where('stock', '>', 0)

    switch (qs.sort) {
      case 'price-asc':
        query.orderBy('price', 'asc')
        break
      case 'price-desc':
        query.orderBy('price', 'desc')
        break
      case 'rating':
        query.orderBy('rating', 'desc')
        break
      case 'savings':
        query.orderByRaw('(mrp - price) desc')
        break
      case 'name':
        query.orderBy('name', 'asc')
        break
      default:
        query.orderBy('featured', 'desc').orderBy('sold', 'desc')
    }

    const products = await query.exec()
    const all = await Product.query().select('category', 'price').exec()

    return {
      count: products.length,
      categories: [...new Set(all.map((p) => p.category))],
      priceBounds: {
        min: Math.min(...all.map((p) => p.price)),
        max: Math.max(...all.map((p) => p.price)),
      },
      products: products.map(presentProduct),
    }
  }

  /**
   * GET /api/products/:id  (id = slug)
   */
  async show({ params, response }: HttpContext) {
    const product = await Product.query()
      .where('slug', params.id)
      .preload('reviews', (q) => q.orderBy('id', 'desc').limit(20))
      .first()

    if (!product) return response.notFound({ error: 'Product not found' })

    const related = await Product.query()
      .where('category', product.category)
      .whereNot('slug', product.slug)
      .orderBy('sold', 'desc')
      .limit(4)

    return {
      product: { ...presentProduct(product), reviews: product.reviews.map(presentReview) },
      related: related.map(presentProduct),
    }
  }

  /**
   * POST /api/products/:id/reviews
   */
  async storeReview({ params, request, response }: HttpContext) {
    const product = await Product.query().where('slug', params.id).first()
    if (!product) return response.notFound({ error: 'Product not found' })

    const payload = await request.validateUsing(reviewValidator)
    const rating = Math.min(5, Math.max(1, Math.round(payload.rating)))

    const review = await product.related('reviews').create({
      name: payload.name,
      rating,
      comment: payload.comment,
    })

    product.rating =
      Math.round(((product.rating * product.numReviews + rating) / (product.numReviews + 1)) * 100) / 100
    product.numReviews += 1
    await product.save()

    return response.created({
      product: presentProduct(product),
      review: presentReview(review),
    })
  }
}
