import CartItem from '#models/cart_item'
import Product from '#models/product'
import CartService from '#services/cart_service'
import type { HttpContext } from '@adonisjs/core/http'

export default class CartController {
  /**
   * GET /api/cart
   */
  async show({ session }: HttpContext) {
    return CartService.getView(String(session.sessionId))
  }

  /**
   * POST /api/cart  { productId (slug), qty }
   */
  async store({ request, response, session }: HttpContext) {
    const { productId, qty } = request.only(['productId', 'qty'])
    const product = await Product.query().where('slug', String(productId || '')).first()
    if (!product) return response.notFound({ error: 'Product not found' })

    const add = Math.max(1, Math.min(20, Number(qty) || 1))
    const sessionId = String(session.sessionId)

    const existing = await CartItem.query()
      .where('sessionId', sessionId)
      .where('productId', product.id)
      .first()

    const currentQty = existing?.qty ?? 0
    if (currentQty + add > product.stock) {
      if (existing) {
        existing.qty = product.stock
        await existing.save()
      }
      return response.conflict({
        error: `Only ${product.stock} in stock.`,
        cart: await CartService.getView(sessionId),
      })
    }

    if (existing) {
      existing.qty = currentQty + add
      await existing.save()
    } else {
      await CartItem.create({ sessionId, productId: product.id, qty: add })
    }

    return CartService.getView(sessionId)
  }

  /**
   * PUT /api/cart/:productId  { qty }  (qty <= 0 removes the line)
   */
  async update({ params, request, response, session }: HttpContext) {
    const qty = Number((request.only(['qty']) as { qty?: unknown }).qty)
    const sessionId = String(session.sessionId)

    const product = await Product.query().where('slug', params.productId).first()
    if (product) {
      const item = await CartItem.query()
        .where('sessionId', sessionId)
        .where('productId', product.id)
        .first()
      if (item) {
        if (!Number.isFinite(qty) || qty <= 0) {
          await item.delete()
        } else {
          item.qty = Math.min(Math.floor(qty), product.stock)
          await item.save()
        }
      }
    } else if (!params.productId) {
      return response.notFound({ error: 'Product not found' })
    }

    return CartService.getView(sessionId)
  }

  /**
   * DELETE /api/cart/:productId
   */
  async destroy({ params, session }: HttpContext) {
    const sessionId = String(session.sessionId)
    const product = await Product.query().where('slug', params.productId).first()
    if (product) {
      await CartItem.query()
        .where('sessionId', sessionId)
        .where('productId', product.id)
        .delete()
    }
    return CartService.getView(sessionId)
  }
}
