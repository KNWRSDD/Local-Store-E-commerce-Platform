import CartItem from '#models/cart_item'
import Order from '#models/order'
import Product from '#models/product'
import CartService from '#services/cart_service'
import OrderTracking from '#services/order_tracking'
import { checkoutValidator } from '#validators/store'
import type { HttpContext } from '@adonisjs/core/http'

export default class OrdersController {
  /**
   * POST /api/orders — checkout: validates the cart, decrements stock,
   * stores the order + line snapshots and clears the cart.
   */
  async store({ request, response, session }: HttpContext) {
    const payload = await request.validateUsing(checkoutValidator)
    const sessionId = String(session.sessionId)
    const cart = await CartService.getView(sessionId)

    if (cart.items.length === 0) {
      return response.badRequest({ error: 'Your cart is empty.' })
    }
    for (const item of cart.items) {
      if (item.qty > item.stock) {
        return response.conflict({
          error: `Only ${item.stock} left of "${item.name}". Please update your cart.`,
        })
      }
    }

    const [{ $extras }] = await Order.query().count('* as total')
    const orderNumber = `GFM-${10241 + Number($extras.total ?? 0)}`

    const order = await Order.create({
      orderNumber,
      sessionId,
      customerName: payload.name,
      phone: payload.phone,
      address: payload.address,
      landmark: payload.landmark || null,
      notes: payload.notes || null,
      payment: payload.payment,
      subtotal: cart.subtotal,
      deliveryFee: cart.deliveryFee,
      total: cart.total,
    })

    await order.related('items').createMany(
      cart.items.map((item) => ({
        name: item.name,
        unit: item.unit,
        emoji: item.emoji,
        image: item.image,
        price: item.price,
        qty: item.qty,
        lineTotal: item.lineTotal,
      }))
    )

    // decrement stock + bump popularity
    for (const item of cart.items) {
      const product = await Product.query().where('slug', item.productId).first()
      if (product) {
        product.stock = Math.max(0, product.stock - item.qty)
        product.sold += item.qty
        await product.save()
      }
    }

    await CartItem.query().where('sessionId', sessionId).delete()

    await order.load('items')
    return response.created({ order: OrderTracking.present(order) })
  }

  /**
   * GET /api/orders — this session's orders, newest first.
   */
  async index({ session }: HttpContext) {
    const orders = await Order.query()
      .where('sessionId', String(session.sessionId))
      .preload('items')
      .orderBy('id', 'desc')

    return { orders: orders.map((order) => OrderTracking.present(order)) }
  }

  /**
   * GET /api/orders/:id — single order with live tracking timeline.
   */
  async show({ params, response, session }: HttpContext) {
    const order = await Order.query()
      .where('orderNumber', params.id)
      .where('sessionId', String(session.sessionId))
      .preload('items')
      .first()

    if (!order) return response.notFound({ error: 'Order not found' })
    return { order: OrderTracking.present(order) }
  }
}
