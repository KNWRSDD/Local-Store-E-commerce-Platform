import SupportTicket from '#models/support_ticket'
import { ticketValidator } from '#validators/store'
import type { HttpContext } from '@adonisjs/core/http'

export default class SupportController {
  /**
   * POST /api/support — raise a customer-support ticket.
   */
  async store({ request, response, session }: HttpContext) {
    const payload = await request.validateUsing(ticketValidator)
    const sessionId = String(session.sessionId)

    const [{ $extras }] = await SupportTicket.query().count('* as total')
    const ticketNumber = `TKT-${121 + Number($extras.total ?? 0)}`

    const ticket = await SupportTicket.create({
      ticketNumber,
      sessionId,
      name: payload.name,
      email: payload.email,
      subject: payload.subject,
      message: payload.message,
      status: 'Open',
      reply:
        'Thanks for reaching out! Our support team will contact you within 24 hours on your email or phone.',
    })

    return response.created({
      ticket: {
        id: ticket.ticketNumber,
        name: ticket.name,
        subject: ticket.subject,
        message: ticket.message,
        status: ticket.status,
        reply: ticket.reply,
        createdAt: ticket.createdAt.toMillis(),
      },
    })
  }

  /**
   * GET /api/support — this session's tickets.
   */
  async index({ session }: HttpContext) {
    const tickets = await SupportTicket.query()
      .where('sessionId', String(session.sessionId))
      .orderBy('id', 'desc')

    return {
      tickets: tickets.map((ticket) => ({
        id: ticket.ticketNumber,
        name: ticket.name,
        email: ticket.email,
        subject: ticket.subject,
        message: ticket.message,
        status: ticket.status,
        reply: ticket.reply,
        createdAt: ticket.createdAt.toMillis(),
      })),
    }
  }
}
