/*
|--------------------------------------------------------------------------
| Routes file
|--------------------------------------------------------------------------
|
| The routes file is used for defining the HTTP routes.
|
*/

import { middleware } from '#start/kernel'
import router from '@adonisjs/core/services/router'
import { controllers } from '#generated/controllers'

const ProductsController = () => import('#controllers/products_controller')
const CartController = () => import('#controllers/cart_controller')
const OrdersController = () => import('#controllers/orders_controller')
const SupportController = () => import('#controllers/support_controller')

/**
 * Health check
 */
router.get('/api', () => ({ name: 'Ghaziabad Fresh Mart API', status: 'ok' }))

/**
 * Storefront API
 */
router
  .group(() => {
    router.get('products', [ProductsController, 'index'])
    router.get('products/:id', [ProductsController, 'show'])
    router.post('products/:id/reviews', [ProductsController, 'storeReview'])

    router.get('cart', [CartController, 'show'])
    router.post('cart', [CartController, 'store'])
    router.put('cart/:productId', [CartController, 'update'])
    router.delete('cart/:productId', [CartController, 'destroy'])

    router.post('orders', [OrdersController, 'store'])
    router.get('orders', [OrdersController, 'index'])
    router.get('orders/:id', [OrdersController, 'show'])

    router.post('support', [SupportController, 'store'])
    router.get('support', [SupportController, 'index'])
  })
  .prefix('api')

/**
 * Auth API (scaffolded with the starter kit — kept for future staff accounts)
 */
router
  .group(() => {
    router
      .group(() => {
        router.post('signup', [controllers.NewAccount, 'store'])
        router.post('login', [controllers.AccessTokens, 'store'])
      })
      .prefix('auth')
      .as('auth')

    router
      .group(() => {
        router.get('profile', [controllers.Profile, 'show'])
        router.post('logout', [controllers.AccessTokens, 'destroy'])
      })
      .prefix('account')
      .as('profile')
      .use(middleware.auth())
  })
  .prefix('/api/v1')
