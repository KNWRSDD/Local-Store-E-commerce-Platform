/* eslint-disable prettier/prettier */
import type { routes } from './index.ts'

export interface ApiDefinition {
  products: {
    index: typeof routes['products.index']
    show: typeof routes['products.show']
    storeReview: typeof routes['products.store_review']
  }
  cart: {
    show: typeof routes['cart.show']
    store: typeof routes['cart.store']
    update: typeof routes['cart.update']
    destroy: typeof routes['cart.destroy']
  }
  orders: {
    store: typeof routes['orders.store']
    index: typeof routes['orders.index']
    show: typeof routes['orders.show']
  }
  support: {
    store: typeof routes['support.store']
    index: typeof routes['support.index']
  }
  auth: {
    newAccount: {
      store: typeof routes['auth.new_account.store']
    }
    accessTokens: {
      store: typeof routes['auth.access_tokens.store']
    }
  }
  profile: {
    profile: {
      show: typeof routes['profile.profile.show']
    }
    accessTokens: {
      destroy: typeof routes['profile.access_tokens.destroy']
    }
  }
}
