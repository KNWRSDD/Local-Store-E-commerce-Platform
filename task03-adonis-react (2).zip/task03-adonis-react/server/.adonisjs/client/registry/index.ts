/* eslint-disable prettier/prettier */
import type { AdonisEndpoint } from '@tuyau/core/types'
import type { Registry } from './schema.d.ts'
import type { ApiDefinition } from './tree.d.ts'

const placeholder: any = {}

const routes = {
  'products.index': {
    methods: ["GET","HEAD"],
    pattern: '/api/products',
    tokens: [{"old":"/api/products","type":0,"val":"api","end":""},{"old":"/api/products","type":0,"val":"products","end":""}],
    types: placeholder as Registry['products.index']['types'],
  },
  'products.show': {
    methods: ["GET","HEAD"],
    pattern: '/api/products/:id',
    tokens: [{"old":"/api/products/:id","type":0,"val":"api","end":""},{"old":"/api/products/:id","type":0,"val":"products","end":""},{"old":"/api/products/:id","type":1,"val":"id","end":""}],
    types: placeholder as Registry['products.show']['types'],
  },
  'products.store_review': {
    methods: ["POST"],
    pattern: '/api/products/:id/reviews',
    tokens: [{"old":"/api/products/:id/reviews","type":0,"val":"api","end":""},{"old":"/api/products/:id/reviews","type":0,"val":"products","end":""},{"old":"/api/products/:id/reviews","type":1,"val":"id","end":""},{"old":"/api/products/:id/reviews","type":0,"val":"reviews","end":""}],
    types: placeholder as Registry['products.store_review']['types'],
  },
  'cart.show': {
    methods: ["GET","HEAD"],
    pattern: '/api/cart',
    tokens: [{"old":"/api/cart","type":0,"val":"api","end":""},{"old":"/api/cart","type":0,"val":"cart","end":""}],
    types: placeholder as Registry['cart.show']['types'],
  },
  'cart.store': {
    methods: ["POST"],
    pattern: '/api/cart',
    tokens: [{"old":"/api/cart","type":0,"val":"api","end":""},{"old":"/api/cart","type":0,"val":"cart","end":""}],
    types: placeholder as Registry['cart.store']['types'],
  },
  'cart.update': {
    methods: ["PUT"],
    pattern: '/api/cart/:productId',
    tokens: [{"old":"/api/cart/:productId","type":0,"val":"api","end":""},{"old":"/api/cart/:productId","type":0,"val":"cart","end":""},{"old":"/api/cart/:productId","type":1,"val":"productId","end":""}],
    types: placeholder as Registry['cart.update']['types'],
  },
  'cart.destroy': {
    methods: ["DELETE"],
    pattern: '/api/cart/:productId',
    tokens: [{"old":"/api/cart/:productId","type":0,"val":"api","end":""},{"old":"/api/cart/:productId","type":0,"val":"cart","end":""},{"old":"/api/cart/:productId","type":1,"val":"productId","end":""}],
    types: placeholder as Registry['cart.destroy']['types'],
  },
  'orders.store': {
    methods: ["POST"],
    pattern: '/api/orders',
    tokens: [{"old":"/api/orders","type":0,"val":"api","end":""},{"old":"/api/orders","type":0,"val":"orders","end":""}],
    types: placeholder as Registry['orders.store']['types'],
  },
  'orders.index': {
    methods: ["GET","HEAD"],
    pattern: '/api/orders',
    tokens: [{"old":"/api/orders","type":0,"val":"api","end":""},{"old":"/api/orders","type":0,"val":"orders","end":""}],
    types: placeholder as Registry['orders.index']['types'],
  },
  'orders.show': {
    methods: ["GET","HEAD"],
    pattern: '/api/orders/:id',
    tokens: [{"old":"/api/orders/:id","type":0,"val":"api","end":""},{"old":"/api/orders/:id","type":0,"val":"orders","end":""},{"old":"/api/orders/:id","type":1,"val":"id","end":""}],
    types: placeholder as Registry['orders.show']['types'],
  },
  'support.store': {
    methods: ["POST"],
    pattern: '/api/support',
    tokens: [{"old":"/api/support","type":0,"val":"api","end":""},{"old":"/api/support","type":0,"val":"support","end":""}],
    types: placeholder as Registry['support.store']['types'],
  },
  'support.index': {
    methods: ["GET","HEAD"],
    pattern: '/api/support',
    tokens: [{"old":"/api/support","type":0,"val":"api","end":""},{"old":"/api/support","type":0,"val":"support","end":""}],
    types: placeholder as Registry['support.index']['types'],
  },
  'auth.new_account.store': {
    methods: ["POST"],
    pattern: '/api/v1/auth/signup',
    tokens: [{"old":"/api/v1/auth/signup","type":0,"val":"api","end":""},{"old":"/api/v1/auth/signup","type":0,"val":"v1","end":""},{"old":"/api/v1/auth/signup","type":0,"val":"auth","end":""},{"old":"/api/v1/auth/signup","type":0,"val":"signup","end":""}],
    types: placeholder as Registry['auth.new_account.store']['types'],
  },
  'auth.access_tokens.store': {
    methods: ["POST"],
    pattern: '/api/v1/auth/login',
    tokens: [{"old":"/api/v1/auth/login","type":0,"val":"api","end":""},{"old":"/api/v1/auth/login","type":0,"val":"v1","end":""},{"old":"/api/v1/auth/login","type":0,"val":"auth","end":""},{"old":"/api/v1/auth/login","type":0,"val":"login","end":""}],
    types: placeholder as Registry['auth.access_tokens.store']['types'],
  },
  'profile.profile.show': {
    methods: ["GET","HEAD"],
    pattern: '/api/v1/account/profile',
    tokens: [{"old":"/api/v1/account/profile","type":0,"val":"api","end":""},{"old":"/api/v1/account/profile","type":0,"val":"v1","end":""},{"old":"/api/v1/account/profile","type":0,"val":"account","end":""},{"old":"/api/v1/account/profile","type":0,"val":"profile","end":""}],
    types: placeholder as Registry['profile.profile.show']['types'],
  },
  'profile.access_tokens.destroy': {
    methods: ["POST"],
    pattern: '/api/v1/account/logout',
    tokens: [{"old":"/api/v1/account/logout","type":0,"val":"api","end":""},{"old":"/api/v1/account/logout","type":0,"val":"v1","end":""},{"old":"/api/v1/account/logout","type":0,"val":"account","end":""},{"old":"/api/v1/account/logout","type":0,"val":"logout","end":""}],
    types: placeholder as Registry['profile.access_tokens.destroy']['types'],
  },
} as const satisfies Record<string, AdonisEndpoint>

export { routes }

export const registry = {
  routes,
  $tree: {} as ApiDefinition,
}

declare module '@tuyau/core/types' {
  export interface UserRegistry {
    routes: typeof routes
    $tree: ApiDefinition
  }
}
