# 🛒 Ghaziabad Fresh Mart — Local Store E-commerce Platform

**Task-03 (Fullstack): AdonisJS backend + React frontend**

An e-commerce website for a neighbourhood store in Ghaziabad, UP. Customers browse products,
filter & sort the catalogue, manage a shopping cart, check out, track orders live, write
reviews, and raise customer-support tickets.

## 🧱 Tech Stack

| Layer | Tech |
|---|---|
| **Backend** | **AdonisJS v7** (TypeScript) — controllers, VineJS validators, `@adonisjs/session` (cookie sessions), `@adonisjs/shield`, `@adonisjs/static` |
| **Database** | **Lucid ORM + SQLite** (better-sqlite3) — 6 migrations, auto-generated model schemas (`database/schema.ts`), seeder |
| **Frontend** | **React** (Vite) — React Router (hash), context-based cart & toasts |
| **Bundling** | `vite build` → `server/public` → served by AdonisJS on a single port |

## 📁 Project structure

```
task03-adonis-react/
├── server/                      # AdonisJS API (port 3333)
│   ├── app/
│   │   ├── controllers/         # products, cart, orders, support
│   │   ├── models/              # Lucid models (extend generated schemas + relations)
│   │   ├── services/            # cart totals, order-tracking timeline
│   │   └── validators/          # VineJS validators
│   ├── database/
│   │   ├── migrations/          # 6 tables: products, reviews, cart_items, orders, order_items, support_tickets
│   │   ├── schema.ts            # auto-generated from DB ("node ace migration:run")
│   │   └── seeders/             # 17-product catalogue seeder
│   ├── start/routes.ts          # /api routes
│   └── public/                  # React build output (served by @adonisjs/static)
└── client/                      # React + Vite app
    └── src/
        ├── App.jsx, main.jsx
        ├── api.js               # fetch wrapper + formatters
        ├── context/             # CartContext, ToastContext
        ├── components/          # Header, Footer, ProductCard, Stars, Media…
        └── pages/               # Home, Shop, ProductDetail, Cart, Checkout, Orders, Track, Support
```

## ✨ Feature coverage

**Core (brief)** — Product listings with images/descriptions/prices, session shopping cart.

**Optional (brief)** — Live order tracking timeline · user reviews with server-side rating
recalculation · support tickets + FAQ · search/filter/sort (category, price range, rating,
stock, 5 sort orders).

## 🚀 Run

> Requires **Node ≥ 22** (built and tested on Node 24).

```bash
# Backend (from task03-adonis-react/server)
npm install
npm run dev            # http://localhost:3333  (serves API + built frontend)

# The SQLite database is included pre-seeded. To recreate it from scratch:
#   node ace migration:run && node ace db:seed

# Frontend dev mode (optional, from task03-adonis-react/client)
npm install
npm run dev            # http://localhost:5173, proxies /api → 3333

# Rebuild frontend into the Adonis-served public folder
npm run build          # outputs to ../server/public
```

## 🔌 API overview

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/products?q=&category=&minPrice=&maxPrice=&minRating=&inStock=&sort=` | List products with filters/sort |
| GET | `/api/products/:id` | Product detail + reviews + related |
| POST | `/api/products/:id/reviews` | Add review `{name, rating, comment}` |
| GET / POST | `/api/cart` | View cart / add `{productId, qty}` |
| PUT / DELETE | `/api/cart/:productId` | Update qty / remove item |
| POST | `/api/orders` | Checkout (VineJS-validated) |
| GET | `/api/orders` · `/api/orders/:id` | My orders · live tracking |
| GET / POST | `/api/support` | My tickets · raise a ticket |

> ℹ️ Order statuses auto-advance on a short timer (Placed → Confirmed → Packed → Out for
> Delivery → Delivered) so tracking demos the full lifecycle live.
