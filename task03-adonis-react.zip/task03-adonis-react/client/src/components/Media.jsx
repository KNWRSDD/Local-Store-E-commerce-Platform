import { useState } from 'react'

/**
 * Product image with emoji-tile fallback if the image is missing/broken.
 */
export default function Media({ item, eager = false }) {
  const [failedSrc, setFailedSrc] = useState(null)
  const showImg = item.image && failedSrc !== item.image

  return (
    <>
      <span className="emo">{item.emoji || '🛍️'}</span>
      {showImg && (
        <img
          src={item.image}
          alt={item.name}
          loading={eager ? 'eager' : 'lazy'}
          onError={() => setFailedSrc(item.image)}
        />
      )}
    </>
  )
}
