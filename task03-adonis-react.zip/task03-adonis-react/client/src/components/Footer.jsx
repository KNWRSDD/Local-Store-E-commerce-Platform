export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <h4>🛒 Ghaziabad Fresh Mart</h4>
          <p>
            Serving Raj Nagar &amp; nearby colonies since 2009 — now delivering to your doorstep in
            60–90 minutes.
          </p>
        </div>
        <div>
          <h5>Visit us</h5>
          <p>
            Shop 12, GDA Market,
            <br />
            Raj Nagar, Ghaziabad, UP 201002
          </p>
        </div>
        <div>
          <h5>Hours</h5>
          <p>
            Mon–Sun: 7:00 AM – 10:00 PM
            <br />
            Delivery slots: every hour
          </p>
        </div>
        <div>
          <h5>Contact</h5>
          <p>
            📞 +91 98765 43210
            <br />
            ✉️ care@ghaziabadfreshmart.in
          </p>
        </div>
      </div>
      <div className="footer-bottom">
        © 2026 Ghaziabad Fresh Mart • Task-03 Fullstack Project (AdonisJS + React)
      </div>
    </footer>
  )
}
