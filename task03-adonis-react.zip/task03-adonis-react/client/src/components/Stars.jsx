export default function Stars({ rating = 0 }) {
  const pct = (Math.max(0, Math.min(5, rating)) / 5) * 100
  return (
    <span className="stars" aria-label={`${rating} out of 5 stars`}>
      <span className="base">★★★★★</span>
      <span className="fill" style={{ width: pct + '%' }}>★★★★★</span>
    </span>
  )
}
