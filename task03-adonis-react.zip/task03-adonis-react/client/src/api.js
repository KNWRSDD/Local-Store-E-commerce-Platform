/** Tiny fetch wrapper + shared formatters for the Fresh Mart API */
export async function api(path, options = {}) {
  const res = await fetch(path, {
    credentials: 'same-origin',
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    body: options.body ? JSON.stringify(options.body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const message =
      data?.errors?.[0]?.message || data?.error || data?.message || 'Something went wrong'
    const err = new Error(message)
    err.data = data
    err.status = res.status
    throw err
  }
  return data
}

export const inr = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

export function orderDate(ts) {
  return new Date(ts).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  })
}

export const CAT_EMOJI = {
  'Staples & Grocery': '🌾',
  'Dairy & Fresh': '🥛',
  'Snacks & Beverages': '🍪',
  'Personal Care': '🧴',
  'Household Essentials': '🧺',
}

export const STATUS_STEPS_ICONS = {
  placed: '🧾',
  confirmed: '✅',
  packed: '📦',
  out: '🛵',
  delivered: '🏠',
}

export function statusClass(key) {
  return 'status-' + key
}
