import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { api } from '../api'
import { useToast } from './ToastContext'

const CartContext = createContext(null)

const EMPTY_CART = { items: [], itemCount: 0, subtotal: 0, deliveryFee: 0, total: 0, freeDeliveryAbove: 499, amountToFreeDelivery: 499 }

export function CartProvider({ children }) {
  const [cart, setCart] = useState(EMPTY_CART)
  const [loaded, setLoaded] = useState(false)
  const { toast } = useToast()

  const refresh = useCallback(async () => {
    try {
      setCart(await api('/api/cart'))
    } catch {
      /* keep previous state */
    } finally {
      setLoaded(true)
    }
  }, [])

  useEffect(() => {
    refresh()
  }, [refresh])

  const addToCart = useCallback(
    async (productId, qty = 1) => {
      try {
        setCart(await api('/api/cart', { method: 'POST', body: { productId, qty } }))
        toast('Added to cart 🛒', 'success')
      } catch (err) {
        if (err.data?.cart) setCart(err.data.cart)
        toast(err.message, 'error')
      }
    },
    [toast]
  )

  const setQty = useCallback(async (productId, qty) => {
    if (qty <= 0) {
      setCart(await api(`/api/cart/${productId}`, { method: 'DELETE' }))
    } else {
      setCart(await api(`/api/cart/${productId}`, { method: 'PUT', body: { qty } }))
    }
  }, [])

  const clearBadge = useCallback(() => setCart(EMPTY_CART), [])

  return (
    <CartContext.Provider value={{ cart, loaded, refresh, addToCart, setQty, clearBadge }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  return useContext(CartContext)
}
