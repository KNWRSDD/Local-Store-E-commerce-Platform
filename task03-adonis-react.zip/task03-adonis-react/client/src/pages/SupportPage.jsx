import { useEffect, useState } from 'react'
import { api, orderDate } from '../api'
import { useToast } from '../context/ToastContext'

const FAQS = [
  ['How fast is delivery?', 'We deliver within 60–90 minutes across Raj Nagar, Kavi Nagar and Savita Vihar. Delivery slots run every hour from 8 AM to 9 PM.'],
  ['Is there a delivery fee?', 'Delivery is free on all orders above ₹499. Below that, a flat ₹40 fee applies.'],
  ['What payment methods do you accept?', 'Cash on Delivery and UPI on delivery (GPay, PhonePe, Paytm). Just scan our QR at the door.'],
  ['What if an item is damaged or missing?', 'Tell us within 24 hours via this page or call +91 98765 43210 — we replace or refund immediately, no questions asked.'],
  ['Can I return fresh items like milk or bread?', 'Fresh items can be flagged at the time of delivery itself for instant replacement.'],
  ['How do I track my order?', 'Open "My Orders" from the menu and tap any order to see its live status timeline.'],
]

const SUBJECTS = ['Order issue', 'Damaged / missing item', 'Refund', 'Delivery feedback', 'Product suggestion', 'Other']

export default function SupportPage() {
  const { toast } = useToast()
  const [tickets, setTickets] = useState([])
  const [form, setForm] = useState({ name: '', email: '', subject: SUBJECTS[0], message: '' })
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)

  const loadTickets = () => api('/api/support').then((d) => setTickets(d.tickets)).catch(() => {})

  useEffect(() => {
    loadTickets()
  }, [])

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))

  const submit = async (e) => {
    e.preventDefault()
    const next = {}
    if (form.name.trim().length < 2) next.name = true
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = true
    if (form.message.trim().length < 10) next.message = true
    setErrors(next)
    if (Object.keys(next).length) return

    setBusy(true)
    try {
      const { ticket } = await api('/api/support', {
        method: 'POST',
        body: { ...form, name: form.name.trim(), email: form.email.trim(), message: form.message.trim() },
      })
      toast(`Ticket ${ticket.id} created — we will reach out soon!`, 'success')
      setForm({ name: '', email: '', subject: SUBJECTS[0], message: '' })
      loadTickets()
    } catch (err) {
      toast(err.message, 'error')
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <h2 className="section-title">Customer support</h2>
      <p className="section-sub">We are here to help — usually within a few hours</p>

      <div className="support-layout">
        <section>
          <h3 style={{ marginBottom: 12 }}>Frequently asked questions</h3>
          {FAQS.map(([q, a]) => (
            <details className="faq" key={q}>
              <summary>{q}</summary>
              <p className="ans">{a}</p>
            </details>
          ))}

          <h3 style={{ margin: '22px 0 12px' }}>My support tickets</h3>
          {tickets.length === 0 && (
            <p className="muted">No tickets yet. Raise one using the form and track it here.</p>
          )}
          {tickets.map((t) => (
            <div className="ticket-row" key={t.id}>
              <div>
                <span className="tid">{t.id}</span> ·{' '}
                <span className="status-chip status-placed">{t.status}</span>
                <div className="subj"><strong>{t.subject}</strong> — {t.message}</div>
                {t.reply && <div className="reply">💬 {t.reply}</div>}
              </div>
              <span className="muted" style={{ fontSize: '.74rem', whiteSpace: 'nowrap' }}>
                {orderDate(t.createdAt)}
              </span>
            </div>
          ))}
        </section>

        <form className="card-panel" noValidate onSubmit={submit}>
          <h3 style={{ marginBottom: 14 }}>✉️ Raise a support ticket</h3>
          <div className={'field' + (errors.name ? ' invalid' : '')}>
            <label>Your name *</label>
            <input type="text" placeholder="e.g. Rahul Verma" value={form.name} onChange={set('name')} />
            <p className="field-err">Please enter your name.</p>
          </div>
          <div className={'field' + (errors.email ? ' invalid' : '')}>
            <label>Email *</label>
            <input type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} />
            <p className="field-err">Enter a valid email address.</p>
          </div>
          <div className="field">
            <label>Subject *</label>
            <select value={form.subject} onChange={set('subject')}>
              {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className={'field' + (errors.message ? ' invalid' : '')}>
            <label>Message *</label>
            <textarea
              maxLength="800"
              placeholder="Describe your issue — include your order ID (e.g. GFM-10241) if it is about an order."
              value={form.message}
              onChange={set('message')}
            />
            <p className="field-err">Please describe your issue (min 10 characters).</p>
          </div>
          <button className="btn btn-primary block" type="submit" disabled={busy}>
            {busy ? 'Submitting…' : 'Submit ticket'}
          </button>
          <p className="free-ship-note" style={{ marginTop: 10, textAlign: 'center' }}>
            Or call us directly: <strong>+91 98765 43210</strong> (7 AM – 10 PM)
          </p>
        </form>
      </div>
    </>
  )
}
