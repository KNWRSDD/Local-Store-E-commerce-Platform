import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, CAT_EMOJI } from '../api'
import ProductCard from '../components/ProductCard'

export default function Home() {
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [search, setSearch] = useState('')

  useEffect(() => {
    api('/api/products').then(setData).catch(() => {})
  }, [])

  const products = data?.products ?? []
  const featured = products.slice(0, 8)
  const categories = (data?.categories ?? []).map((name) => ({
    name,
    emoji: CAT_EMOJI[name] || '🛍️',
    count: products.filter((p) => p.category === name).length,
  }))

  return (
    <>
      <section className="hero">
        <div>
          <h1>
            Everything your kitchen needs, <em>delivered in 60–90&nbsp;min</em>.
          </h1>
          <p>
            Order from Ghaziabad Fresh Mart — your trusted neighbourhood store in Raj Nagar since
            2009. Fresh stock, fair prices, same warm service, now at your doorstep.
          </p>
          <form
            className="hero-search"
            onSubmit={(e) => {
              e.preventDefault()
              navigate('/shop?q=' + encodeURIComponent(search.trim()))
            }}
          >
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search atta, ghee, chai, noodles…"
              aria-label="Search products"
            />
            <button className="btn btn-primary" type="submit">Search</button>
          </form>
          <div className="hero-badges">
            <span>🚚 Free delivery over ₹499</span>
            <span>💵 COD &amp; UPI accepted</span>
            <span>🌿 Freshness guaranteed</span>
          </div>
        </div>
        <div className="hero-media">
          <img
            src="/images/hero.jpg"
            alt="Ghaziabad Fresh Mart storefront"
            onError={(e) => (e.currentTarget.parentElement.style.display = 'none')}
          />
        </div>
      </section>

      <section className="home-section">
        <h2 className="section-title">Shop by category</h2>
        <p className="section-sub">Browse the aisles of your local store</p>
        <div className="cat-grid">
          {categories.map((c) => (
            <div
              key={c.name}
              className="cat-card"
              onClick={() => navigate('/shop?category=' + encodeURIComponent(c.name))}
            >
              <span className="emo">{c.emoji}</span>
              <h4>{c.name}</h4>
              <small>{c.count} items</small>
            </div>
          ))}
        </div>
      </section>

      <section className="home-section">
        <h2 className="section-title">Bestsellers near you</h2>
        <p className="section-sub">Most loved by your neighbours this week</p>
        <div className="prod-grid">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
        <div style={{ textAlign: 'center', marginTop: 22 }}>
          <button className="btn btn-outline" onClick={() => navigate('/shop')}>
            View all products →
          </button>
        </div>
      </section>

      <section className="perk-grid">
        <div className="perk"><span className="emo">⚡</span><div><h5>60–90 min delivery</h5><p>From our shelves to your door</p></div></div>
        <div className="perk"><span className="emo">💵</span><div><h5>COD &amp; UPI</h5><p>Pay how you like, on delivery</p></div></div>
        <div className="perk"><span className="emo">↩️</span><div><h5>Easy returns</h5><p>Issues? We replace, no questions</p></div></div>
        <div className="perk"><span className="emo">🧾</span><div><h5>Honest pricing</h5><p>Same rates as the store counter</p></div></div>
      </section>
    </>
  )
}
