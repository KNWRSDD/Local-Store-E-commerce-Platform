import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api, inr } from '../api'
import Media from '../components/Media'
import ProductCard, { offPct } from '../components/ProductCard'
import Stars from '../components/Stars'
import { useCart } from '../context/CartContext'
import { useToast } from '../context/ToastContext'

export default function ProductDetail() {
  const { id } = useParams()
  const { addToCart } = useCart()
  const { toast } = useToast()

  const [data, setData] = useState(null)
  const [notFound, setNotFound] = useState(false)
  const [qty, setQty] = useState(1)
  const [picked, setPicked] = useState(5)
  const [rvName, setRvName] = useState('')
  const [rvComment, setRvComment] = useState('')

  useEffect(() => {
    setData(null)
    setNotFound(false)
    setQty(1)
    setPicked(5)
    setRvName('')
    setRvComment('')
    api('/api/products/' + encodeURIComponent(id))
      .then(setData)
      .catch(() => setNotFound(true))
  }, [id])

  if (notFound) {
    return (
      <div className="empty-state">
        <div className="big">🔎</div>
        <h3>Product not found</h3>
        <p>It may have been removed from the shelf.</p>
        <Link className="btn btn-primary" to="/shop">Back to shop</Link>
      </div>
    )
  }
  if (!data) return null

  const p = data.product
  const off = offPct(p)
  const stockCls = p.stock <= 0 ? 'out' : p.stock <= 5 ? 'low' : 'in'
  const stockTxt =
    p.stock <= 0 ? '✕ Out of stock' : p.stock <= 5 ? `⚠ Hurry, only ${p.stock} left in stock` : '✓ In stock'

  const submitReview = async () => {
    try {
      await api(`/api/products/${p.id}/reviews`, {
        method: 'POST',
        body: { name: rvName.trim(), rating: picked, comment: rvComment.trim() },
      })
      toast('Thanks! Your review was posted ⭐', 'success')
      setRvName('')
      setRvComment('')
      setData(await api('/api/products/' + encodeURIComponent(id)))
    } catch (err) {
      toast(err.message, 'error')
    }
  }

  return (
    <>
      <p className="breadcrumb">
        <Link to="/">Home</Link> / <Link to="/shop">Shop</Link> /{' '}
        <Link to={'/shop?category=' + encodeURIComponent(p.category)}>{p.category}</Link> / {p.name}
      </p>

      <div className="pd-layout">
        <div className="pd-media">
          <Media item={p} eager />
        </div>
        <div className="pd-info">
          <span className="cat">{p.category}</span>
          <h1>{p.name}</h1>
          <div className="pd-meta">
            <Stars rating={p.rating} />
            <span><strong>{p.rating}</strong> · {p.numReviews} ratings</span> · <span>{p.unit}</span>
          </div>
          <div className="pd-price">
            <span className="price">{inr.format(p.price)}</span>
            {off > 0 && (
              <>
                <span className="mrp">{inr.format(p.mrp)}</span>
                <span className="off">{off}% off</span>
              </>
            )}
          </div>
          <p className="tax-note">Inclusive of all taxes · {p.unit}</p>
          <p className={'stock-note ' + stockCls}>{stockTxt}</p>
          <p className="pd-desc">{p.desc}</p>
          <ul className="pd-details">
            {p.details.map((d) => <li key={d}>{d}</li>)}
          </ul>

          <div className="qty-adder">
            <div className="qty-box">
              <button onClick={() => setQty((v) => Math.max(1, v - 1))} aria-label="Decrease quantity">−</button>
              <span>{qty}</span>
              <button onClick={() => setQty((v) => Math.min(20, v + 1))} aria-label="Increase quantity">+</button>
            </div>
            <button
              className="btn btn-primary"
              style={{ flex: 1 }}
              disabled={p.stock <= 0}
              onClick={() => addToCart(p.id, qty)}
            >
              {p.stock <= 0 ? 'Out of Stock' : `Add to Cart · ${inr.format(p.price * qty)}`}
            </button>
          </div>
          <div className="pd-perks">
            <span>🚚 Delivery in 60–90 min</span>
            <span>💵 COD &amp; UPI</span>
            <span>↩️ No-question replacement</span>
          </div>
        </div>
      </div>

      <section className="reviews">
        <h2 className="section-title">Customer reviews</h2>
        <div className="review-summary">
          <span className="avg">{p.rating}</span>
          <div>
            <Stars rating={p.rating} />
            <p className="muted" style={{ marginTop: 4 }}>Based on {p.numReviews} ratings</p>
          </div>
        </div>

        <div>
          {p.reviews.length === 0 && (
            <p className="muted">No written reviews yet — be the first to review this product.</p>
          )}
          {p.reviews.map((r) => (
            <div className="review-item" key={r.id}>
              <div className="who">
                <span className="avatar">{r.name.trim()[0].toUpperCase()}</span>
                <div>
                  <strong>{r.name}</strong>
                  <br />
                  <Stars rating={r.rating} />
                </div>
                <span className="date">{r.date}</span>
              </div>
              <p>{r.comment}</p>
            </div>
          ))}
        </div>

        <div className="review-form">
          <h4>✍️ Write a review</h4>
          <div className="star-picker">
            {[1, 2, 3, 4, 5].map((i) => (
              <button
                key={i}
                type="button"
                className={i <= picked ? 'on' : ''}
                onClick={() => setPicked(i)}
              >
                ★
              </button>
            ))}
          </div>
          <div className="field">
            <label>Your name</label>
            <input
              type="text"
              maxLength="40"
              placeholder="e.g. Priya Sharma"
              value={rvName}
              onChange={(e) => setRvName(e.target.value)}
            />
          </div>
          <div className="field">
            <label>Your review</label>
            <textarea
              maxLength="500"
              placeholder="How was the quality, packing, freshness…?"
              value={rvComment}
              onChange={(e) => setRvComment(e.target.value)}
            />
          </div>
          <button className="btn btn-primary" onClick={submitReview}>Submit review</button>
        </div>
      </section>

      {data.related.length > 0 && (
        <section className="home-section">
          <h2 className="section-title">You may also like</h2>
          <div className="prod-grid" style={{ marginTop: 16 }}>
            {data.related.map((rp) => <ProductCard key={rp.id} product={rp} />)}
          </div>
        </section>
      )}
    </>
  )
}
